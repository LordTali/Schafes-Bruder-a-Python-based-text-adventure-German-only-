import time
from colorama import *


"""
def WARTEN():
    time.sleep(0.8)


def WARTEN2():
    time.sleep(5)


def WARTEN3():
    time.sleep(4)
"""


def WARTEN():
    time.sleep(0)


def WARTEN2():
    time.sleep(0)


def WARTEN3():
    time.sleep(0)


def HOPPLA():
    print(f"{Fore.WHITE}[Hoppla! Wie es scheint, hat dein erbarmungsloser dunkler Overlord "
          f"(auch bekannt als Spielleiter) diese Antwortmöglichkeit nicht vorgesehen.]{Fore.GREEN}\n")
    WARTEN()
    return


class Status:
    def __init__(self, ENDE, EPILOG, OST, OST_WEG, WEST, SUED, BOOM, OST1_ZURUECK, WEST_SPRUNG, WEST_SUED,
                 WEST_SUED_NORD, WEST_SUED_SUED, WEST_SUED_OST, WEST_NORD_OST,WEST_NORD_WEST,
                 WEST_NORD_SUED, KAMPF, TOT, WIEDERHOLUNG, AUFGEBEN):
        self.ENDE = ENDE  # Jede Art von Versagen
        self.EPILOG = EPILOG  # Erfolg
        self.OST = OST  # Man kommt aus dem Osten.
        self.OST_WEG = OST_WEG  # Man war im Osten.
        self.WEST = WEST  # Man kommt aus dem Westen.
        self.SUED = SUED  # Man kommt aus dem Süden.
        self.BOOM = BOOM  # Man hat die Schmugglerhöhle gesprengt.
        self.OST1_ZURUECK = OST1_ZURUECK  # Zurück zu Ostkorridor 1.
        self.WEST_SPRUNG = WEST_SPRUNG  # Wenn der Charakter zuerst nach Norden geht und dort runterspringt.
        self.WEST_SUED = WEST_SUED  # Wenn der Charakter im Westkorridor von Süden kommt und dann gen Nord will.
        self.WEST_SUED_NORD = WEST_SUED_NORD  # Wenn der Charakter im Westkorridor von Süden kommt
                                              # und dann in den Nordgang will.
        self.WEST_SUED_SUED = WEST_SUED_SUED  # Wenn der Charakter im Westkorridor von Süden kommt
                                              # und wieder gen Süd Nord will.
        self.WEST_SUED_OST = WEST_SUED_OST    # Wenn der Charakter im Westkorridor von Süden kommt
                                              # und wieder zur Kreuzung will.
        self.WEST_NORD_OST = WEST_NORD_OST    # Wenn der Charakter im Westkorridor im Norden war und zurück will.
        self.WEST_NORD_WEST = WEST_NORD_WEST  # Wenn der Charakter im Westkorridor aus der Schmugglerhöhle rausgeht.
        self.WEST_NORD_SUED = WEST_NORD_SUED  # Wenn der Charakter im Westkorridor doch nicht springen will.
        self.KAMPF = KAMPF                    # Der Kampf gegen den Endboss hat begonnen.
        self.TOT = TOT                        # Der Charakter ist tot.
        self.WIEDERHOLUNG = WIEDERHOLUNG      # Neuer Durchlauf, nachdem man bereits einmal gespielt hat.
        self.AUFGEBEN = AUFGEBEN              # Der Charakter gibt auf und verlässt die Höhle.

status = Status(False,False,False, False, False, False, False,
                False, False,False, False,False,
                False,False,False,False,
                False, False, False, False)