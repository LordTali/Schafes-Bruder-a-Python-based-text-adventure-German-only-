from charaktere import *
from konstanten_und_status import *


def raum_westkorridor1():
    print(f"{Fore.WHITE}[Du befindest dich nun im westlichen Gang]{Fore.GREEN} \n")
    WARTEN2()
    print("Der schmale Gang führt weiter in die Tiefen der Säuselhöhle. \n")
    WARTEN2()
    print("Die Wände sind feucht und stark mit Moos bewachsen, und du spürst einen schwachen Windzug.\n")
    WARTEN2()
    print("Du kannst keine Löcher im Gestein erkennen, aber irgendwo müssten die eigentlich sein.\n")
    WARTEN2()
    print("Der Wind zieht mit einem tiefen Ton an dir vorbei, viel tiefer als das hohe Pfeifen am Eingang. \n")
    WARTEN2()
    print("An diesen Ort kannst du dich erinnern, vor allem die Moosschlachten gehörten damals "
          "zu euren Lieblingsspielen.\n")
    WARTEN2()
    print("Oh, wie sauer die Eltern damals doch waren!\n")
    WARTEN2()
    print("Aber zumindest hieß es auch, dass ihr nicht allzu tief in die Höhle vorgestoßen wart.\n")
    WARTEN2()
    print("Niemand kam bei Moosschlachten um. Zumindest, soweit du das beurteilen kannst.\n")
    WARTEN2()
    print("Kinder, die in diesen Gängen Versteckspiele mitmachten, hatten nicht immer so viel Glück. \n")
    WARTEN2()
    print("Der lange Gang öffnet sich schließlich zu einer großen Höhle mit einer Weggabelung. "
          "So tief warst du hier noch nie.\n")
    WARTEN2()
    print("Von hier aus führt ein Gang zu deiner Rechten nach Norden, links einer nach Süden. "
          "Natürlich kannst aber auch wieder zurückgehen.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Süden, Osten) \n >").lower()
        if "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_sued():
    print(f"{Fore.WHITE}[Du folgst dem westlichen Gang nach Süden.]{Fore.GREEN}\n")
    WARTEN2()
    print("Du bist an der Weggabelung nach Süden ab und folgst einem überraschend breiten "
          "und ziemlich langen Gang.\n")
    WARTEN2()
    print("Dir fällt auf, dass der Moos immer weniger wird, je weiter du in die Höhle vordringst.\n")
    WARTEN2()
    print("Hier und da entdeckst du ein paar verwitterte Malereien.\n")
    WARTEN2()
    print("Kinder, die früher in der Säuselhöhle gespielt haben, wagten sich nur selten so weit.\n")
    WARTEN2()
    print("Dabei fragst du dich, wie sie das überhaupt geschafft haben. Licht gibt do tief "
          "in der Höhle nämlich nicht. \n")
    WARTEN2()
    print("Du überlegst, welche Nichtmenschen es damals im Dorf gab. Viele dürften "
          "es eigentlich nicht gewesen sein.\n")
    WARTEN2()
    print("Ein paar Zwergenfamilien kamen erst vor etwa fünf Jahren hierher, "
          "Dunkelelfen hast du hier noch nie gesehen, und Orks waren hier noch nie willkommen.\n")
    WARTEN2()
    print("Andere Rassen mit Dunkelsicht fallen dir nicht ein. Jedenfalls keine Sim'iari, "
          "Menschen sowieso nicht. \n")
    WARTEN2()
    print("Elfen? Nicht, dass du wüsstest...\n")
    WARTEN2()
    print("Wie ist es bei Kurzlingen? Davon gibt es tatsächlich welche im Dorf. "
          "Du müsstest mal einen bei Gelegenheit fragen.\n")
    WARTEN2()
    print("Du glaubst ebenfalls nicht, dass jemand einem Kind eine Fackel in die Hand geben würde.\n")
    WARTEN2()
    print("Und Lampen sind zu teuer.\n")
    WARTEN2()
    print("Aber hier sind sie, die Hinterlassenschaften von Kinderspielen!\n")
    WARTEN2()
    print("Irgendwie müssen sie es also hinbekommen haben.\n")
    WARTEN2()
    print("Gedankenversunken kommst du also voran, die Zeit scheint dabei genau wie "
          "jegliche Geräusche von Draußen immer mehr zu verschwinden.\n")
    WARTEN2()
    return


def raum_westkorridor2_1():
    print(f"{Fore.WHITE}[Du befindest dich in der Tempelhöhle.]{Fore.GREEN}\n")
    WARTEN2()
    print("Vor die öffnet sich eine große Höhle, die genug Platz für eine ganze Dorfversammlung bieten würde.\n")
    WARTEN2()
    print("Mit dem bisschen Licht kannst du leider nicht viel erkennen "
          "- aber scheinbar hatte jemand das so ähnlich gesehen.\n")
    WARTEN2()
    print(
        "Auf dem Boden entdeckst du Spuren: Rituelle Markierungen, Reste irgendwelcher Werkzeuge, "
        "hier und da eine Art Kleidung oder Stoffreste.\n")
    WARTEN2()
    print("Wie es aussieht, war dieser Ort früher von einer Art Kult benutzt. Aber von wem?\n")
    WARTEN2()
    print(
        "Leider kennst du dich in Sachen Religion nicht überhaupt nicht aus. "
        "Die Symbole kommen dir trotzdem bekannt vor...\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Jetzt kannst du dich in Sachen Religion ausprobieren.]\n")
    WARTEN2()
    print("[Als einfacher Bauer kennst du dich hast du in deiner Religionsfertigkeit keine Punkte, "
          f"einen kleinen Bonus hast du drauf trotzdem.]{Fore.GREEN}\n")
    WARTEN2()
    while True:
        befehl = input("Gib nun bitte \"würfeln\" ein. \n > ").lower()
        if "würfeln" in befehl:
            wurf_religion = olig.wurf_religion(14)
            WARTEN2()
            if wurf_religion == True:
                print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Du kannst natürlich nur mutmaßen, aber die Symbole scheinen auf einen Bes hinzudeuten.\n")
                WARTEN2()
                print("Dich schaudert's.")
                WARTEN()
                print("Bessy...böswillige Geister, stets auf der Suche nach Gelegenheiten zum Unheilstiften...\n")
                WARTEN2()
                print("Und manchmal nach einer guten Abmachung mit den Menschen.\n")
                WARTEN2()
                print("Du wusstest gar nicht, dass sie regelrechte Kulte anziehen.\n")
                WARTEN()
                print("Und um welchen Bes es sich dabei handeln soll, "
                      "kannst du sowieso beim besten Willen nicht sagen.\n")
                WARTEN2()
                print("Vielleicht solltest aber später mit dem Dorfältesten sprechen "
                      "- die Spuren scheinen gar nicht so lange her zu sein.\n")
                WARTEN2()

            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Nein. Es fällt dir beim besten Willen nicht ein.\n")
                WARTEN2()
                print("Vielleicht solltest aber später mit dem Dorfältesten sprechen - "
                      "die Spuren scheinen gar nicht so lange her zu sein.\n")
                WARTEN2()
            return
        else:
            HOPPLA()


def raum_westkorridor2_2():
    print("Soweit du es beurteilen kannst, hat diese Höhle nur zwei Ausgänge, "
          "die du ohne weitere Ausrüstung erreichen kannst.\n")
    WARTEN2()
    print("Der Gang im Nordosten des Raums führt nach Norden, im Südosten entdeckst du aber noch einen Gang.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Osten)\n > ").lower()
        if "ost" in befehl:
            return befehl
        elif "nord" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor3():
    WARTEN2()
    print(f"\n{Fore.WHITE}[Du dringst tief in die Säuselhöhle vor.]{Fore.GREEN}\n")
    WARTEN2()
    print("Du folgst dem östlichen Gang noch eine Weile.\n")
    WARTEN2()
    print("Außer leblosem Gestein entdeckst du soweit nichts.\n")
    WARTEN2()
    print("Es scheint fast, als würde sämtliches Leben hier zum Stillstand kommen.\n")
    WARTEN2()
    print("Dann musst du plötzlich anhalten.\n")
    WARTEN2()
    print("Vor dir erstreckt sich ein riesiges Loch.\n")
    WARTEN2()
    print("Du schaust in die Dunkelheit unter dir, entdeckst aber nichts außer der schwarzen Leere.\n")
    WARTEN2()
    print("Mehr noch: Du bekommst das Gefühl, dass die Dunkelheit vielmehr dich betrachtet als du sie.\n")
    WARTEN2()
    print("Zum Glück siehst du auch eine breite Holzbrücke, die über das Loch führt.\n")
    WARTEN2()
    print("Du fragst dich, wer sie gebaut hat.\n")
    WARTEN2()
    print("Und wofür? Wann?\n")
    WARTEN2()
    print("Du gehst du über die Brücke und siehst schließlich etwas.\n")
    WARTEN2()
    print("Licht!\n")
    WARTEN2()
    print("Du kommst dem Licht näher und stehst wieder vor einer grö0eren Höhle.\n")
    WARTEN2()
    print("Was du dort erblickst, lässt sich kaum beschreiben.\n")
    WARTEN2()
    print("Du siehst Dolly - angebunden, mitten in einem Kreis aus einer roten Substanz.\n")
    WARTEN2()
    print("Neben dem Kreis erkennst du einen Tisch mit irgendwelchen Werkzeugen.\n")
    WARTEN2()
    print("Das Ganze sieht verdächtig nach einer Art Opfer-Ritual aus.\n")
    WARTEN2()
    print("Da kommt auch das Licht her. Rituelle Kerzen.\n")
    WARTEN2()
    print("Fast hättest du dich schon gewundert. Orks können ja bekannterweise perfekt im Dunkeln sehen.\n")
    WARTEN2()
    print("Genau wie Zwerge und Dunkelelfen.\n")
    WARTEN2()
    print("Den Übeltäter kannst du auch erkennen.\n")
    WARTEN2()
    print("Ein großer schwarzer Ork ist gerade dabei, eine Klinge zu schärfen.\n")
    WARTEN2()
    print("Dieser Bastard!\n")
    WARTEN2()
    print("Arme Dolly! Du musst sie unbedingt da rausholen!\n")
    WARTEN2()
    print("Der Ork scheint sich dabei mit jemandem zu unterhalten, und schon bald siehst du, mit wem.\n")
    WARTEN2()
    print("Einem Zwerg, den du sofort erkennst.\n")
    WARTEN2()
    print("Wessin. Dein Bauernhof-Nachbar.\n")
    WARTEN2()
    print("Was um alles in der Welt passiert hier eigentlich?\n")
    WARTEN2()
    print("Was immer es ist: Die Zeit ist knapp!\n")
    WARTEN2()
    print("Du hast mehrere Optionen:\n")
    WARTEN2()
    print("Du kannst die Entführer natürlich stellen und versuchen, Dolly mit Worten zurückzuholen.\n")
    WARTEN2()
    print("Würden sie darauf hören? Irgendwie hast du da deine Zweifel. Aber man weiß ja nie.\n")
    WARTEN2()
    print("Du kannst natürlich auch deine Axt rausholen und direkt los schwingen.\n")
    WARTEN2()
    print("Je schneller du mit dem Ork fertig wirst, desto besser.\n")
    WARTEN2()
    print("Den Rest kannst du später klären.\n")
    WARTEN2()
    print("Oder wie wäre es mit einem Überraschungsangriff? Du hast immer noch deine Fackel!\n")
    WARTEN2()
    print("Du hast sie noch nie als Waffe benutzt, aber du hast gehört, dass man sie auch werfen kann.\n")
    WARTEN2()
    print("Einen Versuch könnte es jedenfalls wert sein.\n")
    WARTEN2()
    print("Bis jetzt scheinen dich die Beiden nicht zu bemerken.\n")
    WARTEN2()
    print("Außerdem hast du Glück: Der Ork hat keine Rüstung an. Sein Lederpanzer liegt neben dem Tisch.\n")
    WARTEN2()
    print("Beides kann sich aber jederzeit ändern.\n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: reden, angreifen, Fackel werfen) \n > ").lower()
        if "rede" in befehl:
            WARTEN2()
            return befehl
        elif "greife" in befehl:
            WARTEN2()
            print("Nach kurzer Überlegung zum Schluss, dass du viel zu lange überlegst.\n")
            WARTEN2()
            print("Was immer die Beiden vorhatten, sie kommen hier NICHT mehr lebend raus.\n")
            WARTEN2()
            print("Du umklammerst deine Axt und stürmst auf den Ork zu.\n")
            WARTEN2()
            return befehl
        elif "fackel" in befehl or "werfe" in befehl:
            WARTEN2()
            print("Du überlegst nicht lange, dann wirfst deine Fackel nach dem schwarzen Unhold.\n")
            WARTEN2()
            print("Wenn sie noch nicht brannte, tut sie es spätestens jetzt.\n")
            WARTEN2()
            fackelwurf = olig.wurf_w12()
            angriffswurf = (olig.geschick + fackelwurf - 3)
            print(f"{Fore.WHITE}[Angriffswurf: {angriffswurf}]{Fore.GREEN}\n")
            WARTEN2()
            olig.ausdauer -= 1
            print(f"{Fore.WHITE}[Deine Ausdauer: {olig.ausdauer}/{olig.max_ausdauer}]{Fore.GREEN}\n")
            wuerfel_w4 = random.randint(1, 4)
            WARTEN2()
            if angriffswurf == 1:
                print("Du versuchst, die Fackel zu werfen, "
                      "doch sie gleitet dir vor lauter Aufregung aus der Hand und fällt runter.\n")
                WARTEN2()
                print("Sie macht Krach, und die Entführer werden auf dich aufmerksam.\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Patzer-Wurf: {wuerfel_w4}]{Fore.WHITE}\n")
                WARTEN2()
                if wuerfel_w4 == 4:
                    print("Aber nicht, bevor deine eigene Fackel deine Kleidung in Brand steckt.\n")
                    WARTEN2()
                    feuerschaden = random.randint(1, 6)
                    print(f"Du kannst das Feuer zwar ausklopfen, erleidest dabei jedoch {feuerschaden}"
                          f" Punkte Feuerschaden.\n")
                    WARTEN2()
                    olig.lebenskraft -= feuerschaden
                    print(f"{Fore.WHITE}[Deine Lebenskraft: {olig.lebenskraft}/{olig.max_lebenskraft}]{Fore.GREEN}\n")
                    WARTEN2()
                print("Das Missgeschick hat dich eindeutig nicht gerade bedrohlich aussehen lassen.\n")
                WARTEN2()
                print("Für einen Rückzieher ist es aber zu spät.\n")
                WARTEN2()
                print("Natürlich kannst du aber immer noch versuchen, "
                      "mit den Beiden zu reden und Dolly ohne Gewalt zurückholen.\n")
                WARTEN2()
                while True:
                    befehl = input("Was willst du tun? (Optionen: reden, angreifen) \n > ").lower()
                    if "rede" in befehl:
                        return befehl
                    elif "greife" in befehl:
                        WARTEN2()
                        print("Nach kurzer Überlegung zum Schluss, dass du viel zu lange überlegst.\n")
                        WARTEN2()
                        print("Was immer die Beiden vorhatten, sie kommen hier NICHT mehr lebend raus.\n")
                        WARTEN2()
                        print("Du umklammerst deine Axt und stürmst auf den Ork zu.\n")
                        return befehl
                    else:
                        HOPPLA()
            elif angriffswurf >= ork.verteidigung or fackelwurf == 12:
                print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Deine Fackel dreht sich im Flug, trifft das Scheusal dann aber doch mit der "
                      "Flamme direkt ins Gesicht, bevor er reagieren kann.\n")
                WARTEN2()
                wuerfel_w6_1 = random.randint(1, 6)
                wuerfel_w6_2 = random.randint(1, 6)
                wuerfel_w6_3 = random.randint(1, 6)
                schaden = wuerfel_w6_1 + wuerfel_w6_2 + wuerfel_w6_3
                ork.lebenskraft -= schaden
                print(f"{Fore.WHITE}[Würfel: {wuerfel_w6_1}, {wuerfel_w6_2}, {wuerfel_w6_3}]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Schaden: {schaden}]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Lebenskraft des Gegners: {ork.lebenskraft}/{ork.max_lebenskraft}]{Fore.GREEN}\n")
                WARTEN2()
                print("Der Ork schreit entsetzlich auf. Selbst wenn er hier lebendig wieder herauskommt, "
                      "wird ihn die Verbrennung dieses Treffen nicht vergessen lassen.\n")
                WARTEN2()
                print(f"{Fore.YELLOW}[DER ORK ERHÄLT 2 PUNKTE DEGENERATION.]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Die Degeneration bezeichnet die körperliche Entstellung, "
                      f"die deinem Charakter widerfahren kann.]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Steigt sie zu hoch, kann sich der Charakter nicht mehr "
                      f"unter Leuten blicken lassen.]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Mehr dazu irgendwann im nächsten Abenteuer.]{Fore.GREEN}\n")
                WARTEN2()
                wuerfel_w4 = random.randint(1, 4)
                print(f"{Fore.WHITE}[Würfel: {wuerfel_w4}]{Fore.GREEN}\n")
                WARTEN2()
                if wuerfel_w4 == 4:
                    print("Während die Fackel von seinem verbrannten Gesicht runterfällt, "
                          "berührt sie im Fall seine Kleidung.\n")
                    WARTEN2()
                    feuerschaden = random.randint(1, 6)
                    print(f"Sie fängt sofort Feuer, brennt an seiner Haut und verursacht {feuerschaden} "
                          f"Punkte Feuerschaden, ehe er das Feuer ausklopfen kann.\n")
                    WARTEN2()
                    ork.lebenskraft -= feuerschaden
                    if ork.lebenskraft <= 0:
                        print("Bevor der Ork reagieren kann, breitet sich das feuer aus.\n")
                        WARTEN2()
                        print("scheinbar hatte er sich mit etwas eingeölt.\n")
                        WARTEN2()
                        print("Möglicherweise für das Ritual, das hier stattfinden soll.\n")
                        WARTEN2()
                        print("Letztlich spielt es aber keine Rolle.\n")
                        WARTEN2()
                        print("Der orkische Bastard versucht verzweifelt, das Feuer zu löschen, "
                              "sinkt dann aber auf die Knie, fällt auf den Boden und erstarrt inmitten "
                              "der lichterloh brennenden Flammen.\n")
                        WARTEN2()
                        print("Du hättest nicht gedacht, dass dein Überraschungsangriff so gut funktioniert.\n")
                        WARTEN2()
                        print("Aber du beschwerst dich auch nicht gerade über das Ergebnis.\n")
                        WARTEN2()
                        return
                    else:
                        print("Der Ork bleckt seine Zähne und stürmt grunzend auf dich zu.\n")
                        WARTEN2()
                        print("Deine Hände umklammern reflexartig deine zweihändige Axt.\n")
                        WARTEN2()
                        print("Du machst dich bereit zum Kampf.\n")
                        WARTEN2()
                        return
                else:
                    print("Der Ork bleckt seine Zähne und stürmt grunzend auf dich zu.\n")
                    WARTEN2()
                    print("Deine Hände umklammern reflexartig deine zweihändige Axt.\n")
                    WARTEN2()
                    print("Du machst dich bereit zum Kampf.\n")
                    WARTEN2()
                    return
            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Deine Fackel fliegt direkt am Ork vorbei und landet irgendwo zwischen ihm und Wessin.\n")
                WARTEN2()
                print("Du fragst dich, was du dir bei dieser Aktion eigentlich erhofft hast.\n")
                WARTEN2()
                print("Aber gut. Einen Versuch war es wert.\n")
                WARTEN2()
                print("Nun schauen dich die beiden Entführer an.\n")
                WARTEN2()
                print("Spätestens jetzt wissen sie, dass du hier bist.\n")
                WARTEN2()
                print("Du könntest jetzt natürlich versuchen, wegzurennen.\n")
                WARTEN2()
                print("Aber jetzt bist du schon so weit gekommen!\n")
                WARTEN2()
                print("Außerdem stehen die Chancen für einen Menschen, einem Ork davonzulaufen, "
                      "in der Regel ziemlich schlecht.\n")
                WARTEN2()
                print("Nein, jetzt gibt es kein Zurück mehr!\n")
                WARTEN2()
                print("Du könntest allerdings noch einen letzten Diplomatieversuch wagen.\n")
                WARTEN2()
                while True:
                    befehl = input("Was willst du tun? (Optionen: reden, angreifen) \n > ").lower()
                    if "rede" in befehl:
                        return befehl
                    elif "greife" in befehl:
                        WARTEN2()
                        print("Nach kurzer Überlegung zum Schluss, dass du viel zu lange überlegst.\n")
                        WARTEN2()
                        print("Was immer die Beiden vorhatten, sie kommen hier NICHT mehr lebend raus.\n")
                        WARTEN2()
                        print("Du umklammerst deine Axt und stürmst auf den Ork zu.\n")
                        return befehl
                    else:
                        HOPPLA()

        else:
            HOPPLA()


def raum_westkorridor1_sued_nach_nord():
    print(f"{Fore.WHITE}[Du folgst dem Gang nach Norden.]{Fore.GREEN}\n")
    WARTEN2()
    print("Du gehst geradeaus und folgst einem überraschend breiten und ziemlich langen Gang.\n")
    WARTEN2()
    print("Dir fällt auf, dass der Mooswuchs wieder zunimmt, je weiter du nach Norden vordringst.\n")
    WARTEN2()
    print("Hier und da entdeckst du ein paar verwitterte Malereien.\n")
    WARTEN2()
    print("Kinder, die früher in der Säuselhöhle gespielt haben, wagten sich nur selten so weit.\n")
    WARTEN2()
    print("Dabei fragst du dich, wie sie das überhaupt geschafft haben. "
          "Licht gibt do tief in der Höhle nämlich nicht. \n")
    WARTEN2()
    print("Du überlegst, welche Nichtmenschen es damals im Dorf gab. "
          "Viele dürften es eigentlich nicht gewesen sein.\n")
    WARTEN2()
    print("Ein paar Zwergenfamilien kamen erst vor etwa fünf Jahren hierher.\n")
    WARTEN2()
    print("Dunkelelfen hast du hier noch nie gesehen.\n")
    WARTEN2()
    print("und Orks waren hier sowieso noch nie willkommen.\n")
    WARTEN2()
    print("Andere Rassen mit Dunkelsicht fallen dir nicht ein. "
          "Jedenfalls keine Sim'iari, Menschen sowieso nicht. \n")
    WARTEN2()
    print("Elfen? Nicht, dass du wüsstest...\n")
    WARTEN2()
    print("Wie ist es bei Kurzlingen? Davon gibt es tatsächlich welche im Dorf. "
          "Du müsstest mal einen bei Gelegenheit fragen.\n")
    WARTEN2()
    print("Du glaubst ebenfalls nicht, dass jemand einem Kind eine Fackel in die Hand geben würde.\n")
    WARTEN2()
    print("Und Lampen sind zu teuer.\n")
    WARTEN2()
    print("Aber hier sind sie, die Hinterlassenschaften von Kinderspielen!\n")
    WARTEN2()
    print("Irgendwie müssen sie es also hinbekommen haben.\n")
    WARTEN2()
    print("Gedankenversunken kommst du also voran, die Zeit scheint dabei geradezu zu verschwinden, "
          "die Naturgeräusche von Draußen sind aber langsam wieder zu hören.\n")
    WARTEN2()
    return


def raum_westkorridor1_sued_zurueck():
    print(f"{Fore.WHITE}[Du befindest dich nun im westlichen Gang]{Fore.GREEN} \n")
    WARTEN2()
    print("Du folgst dem kurvigen Gang und kommst wieder zur Weggabelung.\n")
    WARTEN2()
    print("Nun geht es in Richtung Osten zurück zur Kreuzung, Es gäbe allerdings auch den Weg nach Norden.\n")
    WARTEN2()
    print("Natürlich kannst auch dem Gang nach Süden folgen.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Osten, Süden)? \n > ").lower()
        if "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_nord():
    print(f"{Fore.WHITE}[Du folgst dem nördlichen Gang des Westkorridors.]{Fore.GREEN}\n")
    print("Der zunächst gerade Gang biegt schon bald nach links ab.\n")
    WARTEN2()
    print("Die Geräusche von draußen verstummen langsam, bis nur deine eigenen Schritte zum einzigen Geräusch werden, "
          "das du hören kannst.\n")
    WARTEN2()
    print("Der Weg schlängelt sich eine Weile, bis er wieder nach links abbiegt.\n")
    WARTEN2()
    print("Kurz darauf siehst du zu deiner Linken eine Abzweigung, der Gang vor dir führt aber noch weiter.\n")
    WARTEN2()
    print("Hinter dir ginge es aber wieder zurück zur Weggabelung, wenn du lieber zurückgehen willst. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Süden, Osten) \n >").lower()
        if "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_nord_zurueck():
    print("[Du befindest dich nun im westlichen Gang] \n")
    WARTEN()
    print("Du folgst dem kurvigen Gang und kommst wieder zur Weggabelung.\n")
    WARTEN2()
    print("Nun geht es zu deiner Linken zurück zur Kreuzung, vor dir führt aber immer noch "
          "ein anderer Weg nach Süden.\n")
    WARTEN2()
    print("Natürlich kannst auch wieder dem schlangenartigen Gang hinter dir folgen.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Osten, Süden)? \n > ").lower()
        if "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_nord_von_sued():
    print(f"{Fore.WHITE}[Du befindest dich im westlichen Gang.]{Fore.GREEN}\n")
    WARTEN2()
    print("Du sinnierst darüber, ob du runterspringen willst, "
          "überlegst es dir aber doch anders und gehst ein Stück zurück.\n")
    WARTEN2()
    print("Wenn du jetzt weiter geradeaus gehst, Richtung Norden, kommst du wieder zur Weggabelung.\n")
    WARTEN2()
    print("Zu deiner Rechten befindet sich aber eine kleine Abzweigung.\n")
    WARTEN2()
    print("Und natürlich könntest du doch noch dein Glück mit dem tiefen Sprung im Süden versuchen.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Osten, Norden, Süden)\n > ").lower()
        if "ost" in befehl:
            return befehl
        elif "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_nord2():
    print("[Du verlässt die Schmugglerhöhle und gehst zurück in den Gang.]\n")
    WARTEN2()
    print(
        "Der Gang zu deiner Linken führt nun nach Süden, der zu deiner Rechten nach Norden, zurück zum Ausgang.\n")
    WARTEN2()
    print("Die Höhle mit der Schmuggelware liegt nun hinter dir.\n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Süden, Osten) \n > ").lower()
        if "nord" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_westkorridor1_nord3():
    print(f"{Fore.WHITE}[Du folgst dem Gang weiter Richtung Süden.]{Fore.GREEN}\n")
    WARTEN2()
    print("Dabei fällt dir auf, dass dir nichts auffällt.\n")
    WARTEN2()
    print("Kein Moos, keine Spuren.\n")
    WARTEN2()
    print("Gar nichts.\n")
    WARTEN2()
    print("Es ist, als hätte sich noch nie jemand hierher getraut.\n")
    WARTEN2()
    print("Nicht einmal Pflanzen.\n")
    WARTEN2()
    print("Dolly und ihr Entführer schon gar nicht.\n")
    WARTEN2()
    print("Verwundert, und vielleicht noch mehr eingeschüchtert, machst du trotzdem weiter.\n")
    WARTEN2()
    print("Schon bald reißt der Boden ab.\n")
    WARTEN2()
    print("Vor dir liegt eine ziemlich große Höhle.\n")
    WARTEN2()
    print("In dieser Dunkelheit kannst du nicht viel erkennen, aber dort scheint es definitiv weiterzugehen.\n")
    WARTEN2()
    print("Allerdings geht es dort recht tief runter. "
          "Vermutlich könntest du den Fall überstehen, wenn du runterspringst.\n")
    WARTEN2()
    print("Sicher bist du dir dabei jedoch nicht.\n")
    WARTEN2()
    print("Deine einzige andere Option wäre es allerdings, wieder zurückzugehen.\n")
    WARTEN2()
    while True:
        befehl1 = input("Was willst du tun? (Optionen: runterspringen, zurückgehen)\n > ")
        if "gehe" in befehl1:
            return befehl1
        elif "spring" in befehl1:
            WARTEN2()
            print(f"{Fore.WHITE}[Nun brauchen wir wieder einen Wurf, um zu sehen, "
                  f"ob du den Sprung überstehst.]{Fore.GREEN}\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Dieses Mal testen wir also deinen Körperbau.]{Fore.GREEN}\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Gut, eigentlich wäre der Wurf für die Fertigkeit \"Sportlichkeit\".]{Fore.GREEN}\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Als einfacher Bauer hast du diese allerdings nicht trainiert.]{Fore.GREEN}\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Dein Körperbau muss also reichen.]{Fore.GREEN}\n")
            WARTEN2()
            while True:
                befehl2 = input("Gib nun bitte \"würfeln\" ein.\n > ").lower()
                if "würfeln" in befehl2:
                    wurf_koerperbau = olig.wurf_koerperbau(15)
                    WARTEN2()
                    if wurf_koerperbau == True:
                        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Du springst runter und landest auf den Beinen.\n")
                        WARTEN2()
                        print("Der Sprung war höher, als es aussah, aber zum Glück kommst du nur mit Schmerzen "
                              "in den Beinen davon.\n")
                        WARTEN2()
                        print("Du schaust dich um. Auf dem gleichen Wege kommst du schon mal nicht zurück, "
                              "selbst wenn du Dolly findest.\n")
                        WARTEN2()
                        print("Es bleibt also nichts Anderes übrig, als den Raum zu untersuchen.\n")
                        WARTEN2()
                        return befehl1
                    elif wurf_koerperbau in range(12, 15):
                        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Du springst runter und landest auf den Beinen, verlierst aber das "
                              "Gleichgewicht und krachst auf den Boden.\n")
                        WARTEN2()
                        print("Dein gesamter Körper tut weh.\n")
                        WARTEN2()
                        print("Als wäre eine ganze Ochsenherde darüber gelaufen.\n")
                        WARTEN2()
                        print("Irgendwann lässt der Schmerz aber nach.\n")
                        WARTEN2()
                        print("Du hebst den Kopf und fasst dir an das von kleinen Steinen zerkratzte Gesicht.\n")
                        WARTEN2()
                        print("Es tut weh.\n")
                        WARTEN2()
                        print("Aber sich zu beklagen bringt jetzt nichts. Es war ja deine Entscheidung.\n")
                        WARTEN2()
                        print("Du schaust dich um. Der Sprung war höher, als du dachtest.\n")
                        WARTEN2()
                        print("Auf dem gleichen Wege kommst du schon mal nicht zurück, selbst wenn du Dolly findest.\n")
                        WARTEN2()
                        print("Es bleibt also nichts Anderes übrig, als den Raum zu untersuchen.\n")
                        WARTEN2()
                        return befehl1
                    elif wurf_koerperbau == 1:
                        print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Du springst runter und fällst auf den Kopf.\n")
                        WARTEN2()
                        print("Bevor du begreifst, was los ist, brichst du dir das Genick.\n")
                        WARTEN2()
                        print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
                        WARTEN2()
                        print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                        WARTEN2()
                        print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                        WARTEN2()
                        print("Ende \n")
                        WARTEN2()
                        return "tot"
                    else:
                        print(f"{Fore.RED}[MISSERFOLG] {Fore.GREEN}\n ")
                        WARTEN2()
                        print("Du springst runter, aber der Sprung ist eindeutig höher, als du gedacht hast.\n")
                        WARTEN2()
                        print("Du landest ziemlich unglücklich und brichst dir die Beine.\n")
                        WARTEN2()
                        print("Dein Körper tut höllisch weh.\n")
                        WARTEN2()
                        print("Als du dich an den Schmerz langsam gewöhnst, begreift du, "
                              "dass du nicht weitermachen kannst.\n")
                        WARTEN2()
                        print("So schmerzhaft es ist, Dolly hier zurückzulassen, "
                              "ist Überleben jetzt deine Priorität.\n")
                        WARTEN2()
                        print("Du kannst nicht gehen, aber wenn du nur durchhältst, "
                              "kannst du dich vielleicht mir den Armen aus der Höhle rausziehen.\n")
                        WARTEN2()
                        print("Und hoffen, dass dich jemand findet.\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Herzlichen Glückwunsch! Jetzt hast du dich in eine brenzlige Lage "
                              f"hineinmanövriert. Und das ganz ohne Fremdhilfe.]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Aber es ist noch nicht alles verloren.]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Jetzt testen wir dein Durchhaltevermögen.]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Als Bauer hast du schon ziemlich starke Arme. "
                              f"Aber wird das Ausreichen?]{Fore.GREEN}\n")
                        WARTEN2()
                        return befehl2
                else:
                    HOPPLA()
        else:
            HOPPLA()


def rettung_durch_kriechen():
    print(f"{Fore.WHITE}[Der Wurf, den du jetzt ablegen sollst, ist für deine Willenskraft.]{Fore.GREEN}\n")
    WARTEN2()
    while True:
        befehl = input("Gib nun \"würfeln\" ein. \n > ").lower()
        if befehl == "würfeln":
            WARTEN2()
            willenswurf = olig.wurf_willen(14)
            if willenswurf == True:
                print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n ")
                WARTEN2()
                print("Es kostet dich unfassbare Mühe, aber irgendwie schaffst du es, aus der Höhle zu kriechen.\n")
                WARTEN2()
                print(
                    "Immer wieder mit Pausen, dafür unerbittlich kamst du langsam voran, "
                    "in nahezu vollständiger Dunkelheit.\n")
                WARTEN2()
                print("Und schließlich, erreichst du irgendwann dank der schieren Willenskraft den Ausgang "
                      "und kriechst noch ein Stück weiter.\n")
                WARTEN2()
                print("Dann brichst du zusammen.\n")
                WARTEN2()
                print("Erst am nächsten Morgen findet man dich wieder.\n")
                WARTEN2()
                print(
                    "Du hast die Säuselhöhle überlebt, zumindest das kannst als einen kleinen Trostpreis "
                    "nach Hause mitnehmen.\n")
                WARTEN2()
                print("Dolly siehst du allerdings nie wieder.\n")
                WARTEN2()
                print("Damit musst du dich nun abfinden, aber das ist ohnehin nicht mehr dein größtes Problem.\n")
                WARTEN2()
                print("Außer Dolly hast du nämlich auch andere Tiere, die versorgt werden müssen.\n")
                WARTEN2()
                print("Kannst du das mit gebrochenen Beinen machen?\n")
                WARTEN2()
                print("Du hast die Wahl: Gibst du deine Ersparnisse für Futter, einen Gehilfen oder einen Arzt aus?\n")
                WARTEN2()
                print("Kriegst du so den Winter überstanden? Du weißt es nicht.\n")
                WARTEN2()
                if olig.edelsteine == True:
                    print(f"{Fore.YELLOW}[Edelsteine: Ja]{Fore.GREEN}\n")
                    WARTEN2()
                    print("Aber zumindest hast du in ein paar Edelsteine gefunden.\n")
                    WARTEN2()
                    print("Du weißt nicht, wie wertvoll sie sind, aber irgendwas sagt dir, "
                          "dass du sie für gutes Geld verkaufen kannst.\n")
                    WARTEN2()
                    print("Damit sind deine Aussichten für den Winter zumindest weniger schlimm.\n")
                    WARTEN2()
                    print("Es wird schwer. Aber schwere Arbeit hast du noch nie gescheut.\n")
                    WARTEN2()
                    print("Ja. Den Winter wirst du irgendwie überstehen. Davon bist du überzeugt.\n")
                    WARTEN2()
                    print("Und danach... nun...\n")
                    WARTEN2()
                print("Dein Schicksal ist jetzt einzig in den Händen der Götter...\n")
                WARTEN2()
                print("Ende\n")
                WARTEN2()
                return
            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n ")
                WARTEN2()
                print("Du versuchst, selbst in diesem Zustand einen Weg aus der Säuselhöhle zu finden.\n")
                WARTEN2()
                print("Deine Arme sind stark, und du du kommst zunächst gut voran.\n")
                WARTEN2()
                print("Irgendwann lassen aber selbst deine Kräfte nach.\n")
                WARTEN2()
                print("Schließlich brichst du zusammen, allein, in nahezu vollständiger Dunkelheit.\n")
                WARTEN2()
                print("Du kannst einfach keine Kraft mehr aufbringen.\n")
                WARTEN2()
                print("Du weißt in etwa, wo du hin musst, aber der Ausgang scheint unvorstellbar weit weg.\n")
                WARTEN()
                print("Du kannst nicht mehr.\n")
                WARTEN2()
                print("Du bleibst einfach hier.\n")
                WARTEN2()
                print("Für immer.\n")
                WARTEN2()
                print("Das letzte, woran du dich erinnerst, ist das Säuseln des Windzugs über deinem Kopf.\n")
                WARTEN2()
                print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
                WARTEN2()
                print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                WARTEN2()
                print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                WARTEN2()
                print("Ende \n")
                WARTEN2()
                return
        else:
            HOPPLA()


def raum_schmugglerhoehle():
    print(f"{Fore.WHITE}[Du befindest dich in der Schmugglerhöhle.]{Fore.GREEN} \n")
    WARTEN2()
    print("Die kurze und überraschend breite Abzweigung führt zu einer kleinen Nebenhöhle. \n")
    WARTEN2()
    print("Plötzlich reißt der Boden ab, und du kannst gerade noch rechtzeitig anhalten.\n")
    WARTEN2()
    print("Der Raum vor dir liegt etwa einen Meter tiefer, als hätte ein Stück der Nebenhöhle einfach eingestampft.\n")
    WARTEN2()
    print("Von diesem Raum hast du schon mal gehört. \n")
    WARTEN2()
    print("Dieser Raum soll schon so manchen Menschen - und nicht nur Menschen - das Leben gekostet haben. \n")
    WARTEN2()
    print("Die Schauergeschichten kennt man allzu gut. \n")
    WARTEN2()
    print("Abenteuerlustige, die die Säuselhöhle erkunden wollten...\n")
    WARTEN2()
    print("Kinder, die hier früher gespielt haben...\n")
    WARTEN2()
    print("Manchmal konnte man die Unglücklichen noch lebend wieder rausholen.\n")
    WARTEN2()
    print("Meistens nicht.\n")
    WARTEN2()
    print("Bei Kindern war es meistens der Sturz, war die Säuselhäöhle doch einer der ersten Orten, "
          "an denen man nach verschwundenen Kindern gesucht hatte.\n")
    WARTEN2()
    print("Schlecht vorbereitete Wanderer waren vielmehr verhungert oder verdurstet.\n")
    WARTEN2()
    print("Dabei war der Sturz selbst oft gar nicht so schlimm, heißt es.\n")
    WARTEN2()
    print("Die Dala... Stola... Stalagmiten, so hießen die Teile! \n")
    WARTEN2()
    print("An denen haben sich die Unglückseelen viel eher verletzt.\n")
    WARTEN2()
    print("Manchmal war allein das schon tödlich, andere haben sich nur stark genug verletzt,"
          " dass sie selbst nicht mehr herauskamen.\n")
    WARTEN2()
    print("Bald nach dem... Vorfall... Hat die Säuselhöhle aber einen richtig schlimmen Ruf bekommen. \n")
    WARTEN2()
    print("Die Erwachsenen tadelten Ausflüge auf's Schärfste, Kinder hatten Angst, "
          "und Fremde, die das Dorf besuchten, wurden sofort entmutigt.\n")
    WARTEN2()
    print("Nun wird sie nur selten von jemandem aufgesucht.\n")
    WARTEN2()
    print("Und wie es scheint, haben sich Andere diese Tatsache zu Nutzen gemacht. \n")
    WARTEN2()
    print("Vor dir erstecken sich nämlich mehrere Fässer und Truhen unbekannter Herkunft. \n")
    WARTEN2()
    print("Außerdem hat jemand sogar daran gedacht, hier eine Strickleiter anzubringen.\n")
    WARTEN2()
    print("Soweit du es beurteilen kannst, sehen die Sachen eher nach Schmuggelware aus.\n")
    WARTEN2()
    print("Es wäre nicht das erste Mal, dass sich Schmuggler in der Gegend niederlassen, "
          "liegt dein Dorf doch nahe einer Imperialen Straße.\n")
    WARTEN2()
    print("Außerdem haben sich die Unbekannten einen richtig guten Ort dafür ausgesucht, "
          "wo sich doch praktisch niemand mehr so tief in die Höhle traut.\n")
    WARTEN2()
    print("Aber wenn du so drüber nachdenkst: Wer auch immer die Ware hier abgestellt hat, "
          "scheint momentan nicht da zu sein. \n")
    WARTEN()
    print("Da wärst du doch fast versucht, die Ware zu untersuchen!\n")
    WARTEN2()
    print("Dann wiederum: Schmuggler bringen schlechte Neuigkeiten. \n")
    WARTEN2()
    print("Das letzte Mal hat der Schmuggeln in der Region direkt die Imperiale Garde auf den Plan gerufen.\n")
    WARTEN2()
    print("Und DAS kann für niemanden gut enden. \n")
    WARTEN2()
    print("Vielleicht solltest du das Ganze hier einfach zerstören, bevor es Ärger gibt!\n")
    WARTEN2()
    print("Zumindest in einem der Fässer scheint Schwarzer Sand zu sein. \n")
    WARTEN2()
    print("Alles, was du tun musst, ist eine Spur aus dieser Substanz zu als Lunte legen "
          "und mit deiner Fackel anzuzünden.\n")
    WARTEN2()
    print("Andererseits könnte es später zu noch mehr Ärger führen. \n")
    WARTEN2()
    print("Und eigentlich geht dich das Ganze auch nichts an. Dein Ziel ist Dolly. \n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: untersuchen, anzünden, weggehen) \n > ").lower()
        if "gehe" in befehl or "weg" in befehl:
            return befehl
        elif "zünde" in befehl:
            return befehl
        elif "untersuche" in befehl:
            if olig.edelsteine == False:
                print("Du untersuchst den Inhalt der Behälter.\n")
                WARTEN2()
                print("In dem Fässern ist hauptsächlich Schwarzer Sand - eine brennbare und gar explosive Substanz, "
                      "die im Bergbau und einigen Waffen verwendet wird.\n")
                WARTEN2()
                print("In den Truhen liegt alles Mögliche: Kleidung, Edelsteine, einige Waffen, Alkohol.\n")
                WARTEN2()
                print("Leider kannst du außer ein-zwei Edelsteinen nichts davon mitnehmen, "
                      "dafür bist du einfach nicht ausgerüstet.\n")
                WARTEN2()
                print("Vielleicht solltest du das Versteck später melden.\n")
                WARTEN2()
                print("Oder du lässt es.\n")
                WARTEN2()
                print("Oder du jagst das Ganze Zeug hier direkt in die Luft und ersparst allen gleich das Problem.\n")
                WARTEN2()
                print("So oder so: Du verstehst nicht viel von Edelsteinen, "
                      "mit ihnen solltest du aber zumindest um ein-zwei Bur reicher sein.\n")
                WARTEN2()
                print("Für den Winter können diese wörtlich zwischen Leben und Tod entscheiden.\n")
                WARTEN2()
                truhe()
                continue
            else:
                print("Du schaust dir das Schmugglergut noch einmal an, gewinnst aber keine neuen Erkenntnisse.\n")
                WARTEN2()
                print("Und noch mehr Beute kannst du nicht mitnehmen.\n")
                WARTEN2()
                continue
        else:
            HOPPLA()


def truhe():
    while True:
        befehl = input("Willst du ein paar Edelsteine mitnehmen? \n > ").lower()
        if "ja" in befehl:
            print("Du greifst in die Truhe und nimmst eine Handvoll Edelsteine.\n")
            WARTEN2()
            print(f"{Fore.YELLOW}[Edelsteine dem Inventar hinzugefügt.]{Fore.GREEN}\n")
            WARTEN2()
            print("Du verstaust sie in deinem kleinen Beutelchen und entfernst dich von der Truhe.\n")
            WARTEN2()
            olig.edelsteine = True
            return
        elif "nein" in befehl:
            print("Du überlegst kurz, ob du etwas mitgehen lassen solltest.\n")
            WARTEN2()
            print("Die mutmaßlich rechtmäßigen Besitzer würden das wahrscheinlich nicht merken.\n")
            WARTEN2()
            print("Und selbst wenn, würden sie das nicht mit dir in Verbindung bringen können.\n")
            WARTEN2()
            print("Aber du willst das trotzdem lieber nicht riskieren. Außerdem bist du Vieles, "
                  "aber kein Dieb.\n")
            WARTEN2()
            print("Du verwirfst den Gedanken an die Edelsteine und entfernst dich wieder von der Truhe.\n")
            return
        else:
            HOPPLA()


def raum_flucht1():
    print("Du legst eine Spur aus Schwarzem Sand, den du in den Fässern findest, und zündest sie an.\n")
    WARTEN2()
    print("Allerdings bist du weder Bergbauer noch Krieger. Du hättest nicht gedacht, "
          "dass die Spur so schnell kürzer wird.\n")
    WARTEN2()
    print("Oh, Mist! Die Substanz brennt wirklich schnell! \n")
    WARTEN2()
    print("Schnell, du musst sofort hier raus! \n")
    WARTEN2()
    WARTEN2()
    print(f"{Fore.WHITE}[Herzlichen Glückwunsch!]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Jetzt hast du dich in eine brenzlige Lage hineinmanövriert, "
          f"und zwar ganz ohne Fremdhilfe.]{Fore.GREEN}n")
    WARTEN2()
    print(f"{Fore.WHITE}[Dein Spielleiter ist stolz auf dich, und erfüllt mit kindlicher Schadenfreude.]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Aber keine Angst!]{Fore.GREEN} \n")
    WARTEN2()
    print(f"{Fore.WHITE}[Also... Doch, besorgt solltest du schon sein. "
          f"Aber noch ist nicht alles verloren!]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Wenn du Glück hast, kannst du der nahenden Explosion entkommen.]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Dafür sieht das Spielsystem Rettungs- und Glückswürfe vor.] {Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Schaffst du den Rettungswurf, kannst du schneller rennen als die Explosion.]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Verfehlst du nur ganz knapp, dann hast du den Glückswurf geschafft "
          f"und kannst zumindest das Schlimmste verhindern.]{Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Und ansonsten... Nun ja, es hat dich ja niemand gezwungen, "
          f"die Lunte anzuzünden, nicht wahr?] {Fore.GREEN}\n")
    WARTEN2()
    print(f"{Fore.WHITE}[Oh, und BETE, dass du dabei keine 1 würfelst!]{Fore.GREEN}\n")
    WARTEN2()
# Die Idee: Krit. Erfolg - nur 1 Wurf. Jeder Misserfolg - Spiel vorbei. Rettungswurf - 2 Würfe. Glückswurf - 3 Würfe.
    while True:
        befehl = input("Und nun: Gib bitte \"würfeln\" ein. \n > ").lower()
        if "würfeln" in befehl:
            wurf_reflex = olig.wurf_w12() + olig.reflexe    # Hier so kodiert, um Krit. Erfolg zu ermöglichen.
            WARTEN2()
            if wurf_reflex >= 14:
                print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                WARTEN2()
                print("Du begreifst den Ernst der Situation und nimmst die Beine in die Hand. "
                      "Du rennst so schnell du kannst.\n")
                WARTEN2()
                print("Du kannst es zwar selbst nicht glauben, aber durch irgendein Wunder schaffst du es, "
                      "der Explosion hinter dir zu entkommen.\n")
                WARTEN2()
                print("Wenn die Fässer explodieren, bist du schon längst am Rennen.\n")
                WARTEN2()
                print("Allerdings löst die Explosion ein Beben in der Höhle aus. "
                      "Von der Höhlendecke fallen nun große Steine.\n")
                WARTEN2()
                wurf_reflex2 = raum_flucht2()
                if wurf_reflex2 == True:
                    return True
                else:
                    return False
            elif wurf_reflex in range(12, 14):
                print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                WARTEN2()
                print("Du begreifst den Ernst der Situation und nimmst die Beine in die Hand. "
                      "Du rennst so schnell du kannst.\n")
                WARTEN2()
                print("Du kannst es zwar selbst nicht begreifen, aber durch irgendein Wunder schaffst du es, "
                      "der Explosion hinter dir zu entkommen.\n")
                WARTEN2()
                print("Wenn die Fässer explodieren, bist du schon längst am Rennen.\n")
                WARTEN2()
                print("Allerdings wirst du nun von der Flammenwolke durch die Gänge verfolgt.\n")
                WARTEN2()
                wurf_reflex3 = raum_flucht3()
                if wurf_reflex3 == True:
                    return True
                else:
                    return False
            elif wurf_reflex == 1:
                print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Du versuchst, aus der Nebenhöhle zu entkommen, "
                       "aber dein Fuß bleibt in der Strickleiter hängen.\n")
                WARTEN2()
                print("Verzweifelt versuchst, dich zu befreien.\n")
                WARTEN2()
                print("Aber es ist zu spät.\n")
                WARTEN2()
                print("Die Explosion reißt dich in Stücke und bringt den gesamten Gang zum Einstürzen.\n")
                WARTEN2()
                print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
                WARTEN2()
                print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                WARTEN2()
                print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                WARTEN2()
                print("Ende\n")
                WARTEN2()
                return
            elif wurf_reflex == 12:
                print(f"{Fore.LIGHTBLUE_EX}[KRITISCHER ERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Das Glück ist wahrlich mit den Dummen!\n")
                WARTEN2()
                print("Oder zumindest mit den Fahrlässigen.\n")
                WARTEN2()
                print("Durch ein schieres Wunder schaffst du es irgendwie, "
                       "nicht nur der Explosion zu entkommen, sondern auch stets den Flammenzungen "
                       "hinter dir einige Schritte voraus zu sein.\n")
                WARTEN2()
                print("Selbst den fallenden Steinen des Gangs, "
                       "der vor deinen Augen einstürzt, kannst du ausweichen.\n")
                WARTEN2()
                print("Unfassbar! Aber auch wahr.\n")
                WARTEN2()
                print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                WARTEN2()
                print("Doch kaum hattest du Luft geholt, hörst du aus den Tiefen der Höhle schwere Schritte.\n")
                WARTEN2()
                print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                WARTEN2()
                print("Er bleckt seine scharfen Zähne und schaut dich wütend an.\n")
                WARTEN2()
                print("Dolly ist nirgends zu sehen, aber du erkennst eine andere Gestalt neben ihm.\n")
                WARTEN2()
                print("Wessin. Dein Bauernhof-Nachbar.\n")
                WARTEN2()
                print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                WARTEN2()
                print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                WARTEN2()
                print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                WARTEN2()
                print("Du machst dich auf einen Kampf gefasst. \n")
                WARTEN2()
                return True
            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Du versuchst, der Explosion zu entkommen, aber du bist nicht schnell genug.\n")
                WARTEN2()
                print("Du hörst einen lauten Knall hinter dir, "
                       "dann wirst du von einer Druckwelle und den Flammen erwischt.\n")
                WARTEN2()
                print("Du liegst da. Auf dem kalten Boden. \n")
                WARTEN2()
                print("Schwer verletzt von der Explosion. Verbrannt von den Flammen.\n")
                WARTEN2()
                print("Du kannst dich nicht mehr bewegen.\n")
                WARTEN2()
                print("Selbst wenn jetzt noch jemand zu deiner Rettung kommen würde, "
                      "könnte man wahrscheinlich nichts mehr tun.\n")
                WARTEN2()
                print("Das letzte, was du siehst, sind große Steine, die auf dich fallen. "
                      "Die Explosion hat den Gang zum Einstürzen gebracht.\n")
                WARTEN2()
                print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
                WARTEN2()
                print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                WARTEN2()
                print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                WARTEN2()
                print("Ende \n")
                WARTEN2()
                return
        else:
            HOPPLA()


def raum_flucht2():
    while True:
        befehl = input("[Gib nun wieder 'würfeln' für einen zweiten Rettungswurf ein.]\n > ").lower()
        if "würfeln" in befehl:
            wurf_reflex_2 = olig.reflexwurf(14)
            WARTEN2()
            if wurf_reflex_2 == True:
                print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                WARTEN2()
                print("Unglaublig, aber du schaffst es, allen Gefahren zum Trotz z"
                      "urück bis zur Kreuzung zu rennen.\n")
                WARTEN2()
                print("Unbeschadet!\n")
                WARTEN2()
                print("Außer Atem, aber heilfroh, kommst du zum Stehen.\n")
                WARTEN2()
                print("Doch kaum hattest du Luft geholt, hörst du aus den Tiefen "
                      "der Höhle schwere Schritte.\n")
                WARTEN2()
                print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                WARTEN2()
                print("Er bleckt seine scharfen Zähne und schaut dich wütend an.\n")
                WARTEN2()
                print("Dolly ist nirgends zu sehen, aber du erkennst eine andere Gestalt neben ihm.\n")
                WARTEN2()
                print("Wessin. Dein Bauernhof-Nachbar.\n")
                WARTEN2()
                print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                WARTEN2()
                print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                WARTEN2()
                print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                WARTEN2()
                print("Du machst dich auf einen Kampf gefasst. \n")
                WARTEN2()
                return True
            elif wurf_reflex_2 in range(12, 14):
                print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                WARTEN2()
                print("Du schaffst es zwar, den großen fallenden Steinen auszuweichen, "
                      "wirst aber von einem Haufen kleiner scharfer Steinchen getroffen.\n")
                WARTEN2()
                print("Wenn du Glück hast, bekommst du nur ein paar Kratzer, "
                      "im schlimmsten Fall werden auch später ein-zwei hässliche Narben bleiben.\n")
                WARTEN2()
                print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                WARTEN2()
                print("Doch kaum hattest du Luft geholt, "
                      "hörst du aus den Tiefen der Höhle schwere Schritte.\n")
                WARTEN2()
                print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                WARTEN2()
                print("Er bleckt seine scharfen Zähne und schaut dich wütend an.\n")
                WARTEN2()
                print("Dolly ist nirgends zu sehen, aber du erkennst eine andere Gestalt neben ihm.\n")
                WARTEN2()
                print("Wessin. Dein Bauernhof-Nachbar.\n")
                WARTEN2()
                print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                WARTEN2()
                print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                WARTEN2()
                print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                WARTEN2()
                print("Du machst dich auf einen Kampf gefasst. \n")
                WARTEN2()
                return True
            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Du versuchst, dich in Sicherheit zu bringen.\n")
                WARTEN2()
                print("Erst sieht es danach aus, als würdest du hier doch noch heil rauskommen.\n")
                WARTEN2()
                print("Dann wirst du aber von einem großen Stein erwischt.\n")
                WARTEN2()
                print("Du taumelst, verlierst das Tempo.\n")
                WARTEN2()
                print("Und bevor du weißt, was passiert ist, wirst du im einstürzenden Tunnel begraben.\n")
                WARTEN2()
                print("Vielleicht werden dir die Götter Gnade walten lassen, "
                      "die du im Leben nicht kanntest.\n")
                WARTEN2()
                print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                WARTEN2()
                print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                WARTEN2()
                print("Ende \n")
                WARTEN2()
                return


def raum_flucht3():
    while True:
        befehl = input("Gib nun wieder \"würfeln\" für einen zweiten Rettungswurf ein.\n > ").lower()
        if "würfeln" in befehl:
            wurf_reflex_3 = olig.reflexwurf(12)
            WARTEN2()
            if wurf_reflex_3 == True:
                print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                WARTEN()
                print("Die Flammen bleiben dir dicht auf den Fersen, aber du schaffst es durch "
                      "unglaubliches Glück, immer einen Schritt voraus zu sein.\n")
                WARTEN2()
                print("Allerdings löst die Explosion ein Beben in der Höhle aus. "
                      "Von der Höhlendecke fallen nun große Steine.\n")
                WARTEN2()
                while True:
                    befehl = input("[Gib nun wieder \"würfeln\" für einen "
                                   "dritten Rettungswurf ein.]\n > ").lower()
                    if "würfeln" in befehl:
                        wurf = olig.reflexwurf(14)
                        WARTEN2()
                        if wurf == True:
                            print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Unglaublig, aber du schaffst es, allen Gefahren zum Trotz "
                                  "zurück bis zur Kreuzung zu rennen.\n")
                            WARTEN2()
                            print("Unbeschadet!\n")
                            WARTEN2()
                            print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                            WARTEN2()
                            print("Doch kaum hattest du Luft geholt, hörst du aus den "
                                  "Tiefen der Höhle schwere Schritte.\n")
                            WARTEN2()
                            print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                            WARTEN2()
                            print("Er bleckt seine scharfen Zähne und schaut dich wütend an.\n")
                            WARTEN2()
                            print("Dolly ist nirgends zu sehen, aber du erkennst eine andere "
                                  "Gestalt neben ihm.\n")
                            WARTEN2()
                            print("Wessin. Dein Bauernhof-Nachbar.\n")
                            WARTEN2()
                            print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                            WARTEN2()
                            print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                            WARTEN2()
                            print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                            WARTEN2()
                            print("Du machst dich auf einen Kampf gefasst. \n")
                            WARTEN2()
                            return True
                        elif wurf in range(12, 14):
                            print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Du schaffst es zwar, den großen fallenden Steinen auszuweichen, "
                                  "wirst aber von einem Haufen kleiner scharfer Steinchen getroffen.\n")
                            WARTEN2()
                            print("Wenn du Glück hast, bekommst du nur ein paar Kratzer, "
                                  "im schlimmsten Fall werden auch später ein-zwei hässliche "
                                  "Narben bleiben.\n")
                            WARTEN2()
                            print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                            WARTEN2()
                            print("Doch kaum hattest du Luft geholst, hörst du aus den Tiefen der "
                                  "Höhle schwere Schritte.\n")
                            WARTEN2()
                            print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                            WARTEN2()
                            print("Er bleckt seine scharfen Zähne und schsut dich wütend an.\n")
                            WARTEN2()
                            print("Dolly ist nirgends zu sehen, aber du erkennst eine andere "
                                  "Gestalt neben ihm.\n")
                            WARTEN2()
                            print("Wessin. Dein Bauernhof-Nachbar.\n")
                            WARTEN2()
                            print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                            WARTEN2()
                            print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                            WARTEN2()
                            print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                            WARTEN2()
                            print("Du machst dich auf einen Kampf gefasst. \n")
                            WARTEN2()
                            return True
                        else:
                            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Du versuchst, dich in Sicherheit zu bringen.\n")
                            WARTEN2()
                            print("Erst sieht es danach aus, als würdest du hier doch "
                                  "noch heil rauskommen.\n")
                            WARTEN2()
                            print("Dann wirst du aber von einem großen Stein erwischt.\n")
                            WARTEN2()
                            print("Du taumelst, verlierst das Tempo.\n")
                            WARTEN2()
                            print("Und bevor du weißt, was passiert ist, "
                                  "wirst du im einstürzenden Tunnel begraben.\n")
                            WARTEN2()
                            print("Vielleicht werden dir die Götter Gnade walten lassen, "
                                  "die du im Leben nicht kanntest.\n")
                            WARTEN2()
                            print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                            WARTEN2()
                            print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                            WARTEN2()
                            print("Ende \n")
                            return
                    else:
                        HOPPLA()
            elif wurf_reflex_3 in range(10, 12):
                print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                WARTEN2()
                print("Die Flammen lecken deinen Rücken, deine Beine, deinen Kopf.\n")
                WARTEN2()
                print("Erst sieht es aus, als würden sie dich gänzlich verschlingen.\n")
                WARTEN2()
                print("Nur durch schiere Willenskraft schaffst du es trotzdem irgendwie, "
                      "weiterzurennen, un einen Flammen einen halben Schritt voraus zu sein.\n")
                WARTEN2()
                print("Allerdings löst die Explosion ein Beben in der Höhle aus. "
                      "Von der Höhlendecke fallen nun große Steine.\n")
                WARTEN2()
                while True:
                    befehl = input("Gib nun wieder \"würfeln\" für einen "
                                   "dritten Rettungswurf ein.]\n > ").lower()
                    if "würfeln" in befehl:
                        wurf_reflex_4 = olig.reflexwurf(14)
                        if wurf_reflex_4 == True:
                            print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Unglaublig, aber du schaffst es, allen Gefahren zum Trotz zurück "
                                  "bis zur Kreuzung zu rennen.\n")
                            WARTEN2()
                            print("Unbeschadet!\n")
                            WARTEN2()
                            print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                            WARTEN2()
                            print("Doch kaum hattest du Luft geholt, hörst du aus den Tiefen der "
                                  "Höhle schwere Schritte.\n")
                            WARTEN2()
                            print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                            WARTEN2()
                            print("Er bleckt seine scharfen Zähne und schaut dich wütend an.")
                            WARTEN2()
                            print("Dolly ist nirgends zu sehen, aber du erkennst eine andere Gestalt neben ihm.\n")
                            WARTEN2()
                            print("Wessin. Dein Bauernhof-Nachbar.\n")
                            WARTEN2()
                            print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                            WARTEN2()
                            print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                            WARTEN2()
                            print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                            WARTEN2()
                            print("Du machst dich auf einen Kampf gefasst. \n")
                            WARTEN2()
                            return True
                        elif wurf_reflex_4 in range(12, 13):
                            print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Du schaffst es zwar, den großen fallenden Steinen auszuweichen, "
                                  "wirst aber von einem Haufen kleiner scharfer Steinchen getroffen.\n")
                            WARTEN2()
                            print("Wenn du Glück hast, bekommst du nur ein paar Kratzer, "
                                  "im schlimmsten Fall werden auch später ein-zwei hässliche Narben bleiben.\n")
                            WARTEN2()
                            print("Außer Atem, aber heilfroh kommst du zum Stehen.\n")
                            WARTEN2()
                            print("Doch kaum hattest du Luft geholt, hörst du aus den "
                                  "Tiefen der Höhle schwere Schritte.\n")
                            WARTEN2()
                            print("Dann zeigt er sich: Ein großer schwarzer Ork.\n")
                            WARTEN2()
                            print("Er bleckt seine scharfen Zähne und schaut dich wütend an.\n")
                            WARTEN2()
                            print("Dolly ist nirgends zu sehen, aber du erkennst eine andere Gestalt neben ihm.\n")
                            WARTEN2()
                            print("Wessin. Dein Bauernhof-Nachbar.\n")
                            WARTEN2()
                            print("Was um alles in der Welt macht er hier? Was ist hier los?\n")
                            WARTEN2()
                            print("Auf Reden scheinen die beiden leider nicht aus zu sein.\n")
                            WARTEN2()
                            print("So hast du es dir nicht vorgestellt, aber die Würfel sind gefallen.\n")
                            WARTEN2()
                            print("Du machst dich auf einen Kampf gefasst. \n")
                            WARTEN2()
                            return True
                        else:
                            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                            WARTEN2()
                            print("Du versuchst, dich in Sicherheit zu bringen.\n")
                            WARTEN2()
                            print("Erst sieht es danach aus, als würdest du hier doch noch heil rauskommen.\n")
                            WARTEN2()
                            print("Dann wirst du aber von einem großen Stein erwischt.\n")
                            WARTEN2()
                            print("Du taumelst, verlierst das Tempo.\n")
                            WARTEN2()
                            print("Und bevor du weißt, was passiert ist, wirst du im einstürzenden Tunnel begraben.\n")
                            WARTEN2()
                            print("Vielleicht werden dir die Götter Gnade walten lassen, "
                                  "die du im Leben nicht kanntest.\n")
                            WARTEN2()
                            print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                            WARTEN2()
                            print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                            WARTEN2()
                            print("Ende \n")
                            WARTEN2()
                            return
                    else:
                        HOPPLA()
            else:
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                WARTEN2()
                print("Du versuchst, den Flammen zu entkommen, bist aber nicht schnell genug.\n")
                WARTEN2()
                print("Die Flammen holen dich ein und verschlingen dich.\n")
                WARTEN2()
                print("Als das Feuer verschwindet, liegst du da. Auf dem kalten Boden. \n")
                WARTEN2()
                print("Schwer verletzt von der Explosion. Verbrannt von den Flammen.\n")
                WARTEN2()
                print("Du kannst dich nicht mehr bewegen. \n")
                WARTEN2()
                print("Selbst wenn jetzt noch jemand zu deiner Rettung kommen würde, "
                      "könnte man wahrscheinlich nichts mehr tun.\n")
                WARTEN2()
                print("Das letzte, was du siehst, sind große Steine, die auf dich fallen. \n")
                WARTEN2()
                print("Die Explosion hat den Gang zum Einsturz gebracht.\n")
                WARTEN2()
                print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
                WARTEN2()
                print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                WARTEN2()
                print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                WARTEN2()
                print("Ende \n")
                WARTEN2()
                return


