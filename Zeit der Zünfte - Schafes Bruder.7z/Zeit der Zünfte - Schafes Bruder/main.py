"""Diese Datei steuert den Programmablauf"""

""" 
\"Zeit der Zünfe: Schafes Bruder \" (c) by Vitali Hänisch

\"Zeit der Zünfe: Die Aufnahmeprüfung\" is licensed under a
Creative Commons Attribution-NoDerivatives 4.0 International License
"""


from navigation import *

"""
begegnung.teilnehmer_hinzufuegen(olig)
begegnung.teilnehmer_hinzufuegen(ork)
begegnung.gegner_hinzufuegen(ork)
begegnung.initiative_wuerfeln()
begegnung.reihenfolge_bestimmen()
begegnung.reihenfolge_anzeigen()
begegnung.kampf_beginnen()  # Der Rundenzähler händelt den Ablauf.
# Danach kommt Sieg oder Niederlage.
while len(begegnung.teilnehmer) > 1:
    begegnung.runden_zaehler()
    for kaempfer in begegnung.teilnehmer:
        if kaempfer == olig:
            ziel = ork
        else:
            ziel=olig
        if kaempfer.lebenskraft <= 0:
            begegnung.teilnehmer.remove(kaempfer)
            continue
        kaempfer.handeln(ziel)
else:
    if olig.lebenskraft > 0:
        szene2_bosskampf()
        frage = szene_sieg()
        if frage:
            EPILOG = True
    else:
        TOT = True
        ENDE = True
        szene_niederlage()
"""

# Spielablauf


if __name__ == "__main__":

    while True:         # Game Loop
        if status.WIEDERHOLUNG:     # Bei einem wiederholten Spiel werden Startmeldungen übersprungen,
            pass                    # und es geht direkt mit dem Spiel los.
        else:
            einleitung()
        while not status.ENDE:  # Solange kein Tod oder Bosskampf auftritt bzw. der Charakter weggeht - freie Bewegung.
            raum_start4()
            frage = raum_start5()   # Erstes Versagen möglich.
            if not frage:
                status.ENDE = True         # Fail State
                continue
            else:
                frage = raum_start6()   # Sonst geht es weiter. Zweites Versagen möglich.
                if not frage:
                    status.ENDE = True
                    continue
                else:                   # Wenn kein Versagen an zweiter Stelle, geht es weiter.
                    while not status.ENDE:  # Solange das Spiel nicht vorbei ist, freie Bewegung.
                        frage = kreuzung()  # Der Charakter ist an der Kreuzung.
                        if "nord" in frage:
                            frage = nordgang()          # Der Charakter geht nach Norden und raus.
                            if not frage:
                                status.ENDE = True     # Der Charakter gibt auf. Noch ein Epilog dazu nötig.
                                status.AUFGEBEN = True
                                break
                            else:               # Der Charakter wagt sich wieder in die Höhle.
                                continue
                        elif "west" in frage:
                            abenteuer_west()          # Der Charakter ist im Westkorridor. Hier potentiell Bosskampf.
                            if status.TOT or status.KAMPF or status.ENDE:   # Das Spiel ist vorbei. Jetzt der Schluss.
                                break
                            else:
                                continue
                        elif "süd" in frage:        # Der Charakter ist im Südkorridor. Hier potentiell Bosskampf.
                            abenteuer_sued()
                            if status.TOT or status.KAMPF or status.ENDE:    # Das Spiel ist vorbei. Jetzt der Schluss.
                                break
                            else:
                                continue
                        else:                   # Der Charakter ist im Ostkorridor.
                            abenteuer_ost()
                            continue
                    else:
                        break
        else:
            if status.EPILOG:
                szene_epilog()              # Der Charakter hat den Boss besiegt oder überredet.
            if status.WEST_SPRUNG:          # Der Charakter hat sich beim Sprung im Westkorridor verletzt.
                if status.TOT:              # Der Charakter ist tot.
                    pass
                else:
                    rettung_durch_kriechen()  # Der Charakter ist nach dem Sprung verletzt, kann sich aber evtl. retten.
            olig.edelsteine = False             # Zurücksetzen der Werte für ein potentielles Wiederholungsspiel.
            olig.westgang = False
            olig.panzerung = keine_ruestung
            frage = fortsetzen()            # Noch einmal spielen?
            if frage:
                status.WIEDERHOLUNG = True  # Noch einmal spielen.
                status.ENDE = False         # Die restliche Spielwelt wird zurückgesetzt.
                status.OST = False
                status.OST_WEG = False,
                status.WEST = False
                status.SUED = False
                status.BOOM = False
                status.OST1_ZURUECK = False
                status.WEST_SPRUNG = False
                status.WEST_SUE = False
                status.WEST_SUED_NORD = False
                status.WEST_SUED_SUED = False
                status.WEST_SUED_OST = False
                status.WEST_NORD_OST = False
                status.WEST_NORD_WEST = False
                status.WEST_NORD_SUED = False
                status.KAMPF = False
                status.TOT = False
                status.AUFGEBEN = False
                status.EPILOG = False
                continue
            else:
                WARTEN2()
                print("Auf Wiedersehen! Danke fürs Spielen!\n")
                WARTEN2()
                quit()
