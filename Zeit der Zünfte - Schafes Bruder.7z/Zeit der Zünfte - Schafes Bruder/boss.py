from charaktere import *
from konstanten_und_status import *


def szene_bosskampf():
    WARTEN2()
    print(f"{Fore.WHITE}[Nun befindest du dich im Kampf.]{Fore.GREEN}\n")
    WARTEN2()
    while True:
        befehl = input("Willst du die Regeln dazu erfahren? \n > ").lower()
        if "ja" in befehl:
            WARTEN2()
            print(f"{Fore.WHITE}[Wie in den meisten Rollenspielen auch, ist der Kampf hier in Runden gegliedert.]\n")
            WARTEN3()
            print("[Wer zuerst angreifen darf, wird gleich über die sogenannte \"Initiative\" entschieden.]\n")
            WARTEN3()
            print("[Dazu würfelt jeder einmal 1W12 und addiert seine Reflexe.]\n")
            WARTEN3()
            print("[Um den Gegner zu besiegen, musst du seine Lebenskraft auf 0 reduzieren.]\n")
            WARTEN3()
            print("[Dafür musst du mit deinem Wurf seinen Verteidigungswert überwinden.]\n")
            WARTEN3()
            print("[Ziemlich viel Zufallsprinzip? Ja, willkommen in der Welt der Rollenspiele!]\n")
            WARTEN3()
            print("[Aber du kannst das Ergebnis mit deinen Entscheidungen beeinflussen.]\n")
            WARTEN2()
            print("[Der Kampf für dieses Abenteuer ist allerdings vereinfacht.]\n")
            WARTEN3()
            print("[Eigentlich sieht das ZdZ-System fünf verschiedene Kampfstile vor.]\n")
            WARTEN3()
            print("[Nicht zu vergessen: Viele verschiedene Aktionen, die man im Kampf machen kann:]\n")
            WARTEN3()
            print("[Kampfbewegung, Boni, Waffenverhalten, Vorteile und Vieles mehr.]\n")
            WARTEN3()
            print("[Vielleicht wird das alles im nächsten Abenteuer eingebaut, "
                  "aber vorerst bleiben wir bei den Grundlagen.]\n")
            WARTEN3()
            print("[Aber als kleiner Vorgeschmack:\n")
            WARTEN3()
            print("[Ruhige Angriffe sind der Standard für jeden Kampfteilnehmer.]\n")
            WARTEN3()
            print("[Gehst du aggressiv vor, achtest du mehr auf deine Treffsicherheit "
                  "und Schaden als die eigene Verteidigung.]\n")
            WARTEN3()
            print("[Bei vorsichtigen Angriffen ist es umgekehrt.]\n")
            WARTEN3()
            print("[Natürlich kannst du auch versuchen, einfach mal nicht getroffen zu werden.]\n")
            WARTEN3()
            print("[Hier sind die Regeln: Jeder Kampfteilnehmer hat 2 Aktionen zur Verfügung.]\n")
            WARTEN3()
            print("[Normalerweise kann man sie für alles Mögliche benutzen, "
                  "aber hier werden sie alle für den Kampf ausgegeben.]\n")
            WARTEN3()
            print("[Außerdem hat jeder Kämpfer eine bestimmte Ausdauer, also eine Kraftreserve, "
                  "die mit jeder Aktion beim Kämpfen verbraucht wird.]\n")
            WARTEN3()
            print("[Fällt sie auf 0, wirst du erschöpft. Dass das mitten im Kampf passiert, willst du nicht.]\n")
            WARTEN3()
            print("[Wirklich nicht.]\n")
            WARTEN3()
            print("[Erschwerend kommt hinzu: Wenn dich ein angriff nur knapp verfehlt, heißt es, du bist aktiv "
                  "ausgewichen]\n")
            WARTEN3()
            print("[Auch das verbraucht Ausdauer.]\n")
            WARTEN3()
            print("[Sie erholt sich aber, wenn du nicht kämpfst bzw. gar nichts machst.]\n")
            WARTEN3()
            print("[Und die gute Nachricht ist: Dein Gegner kämpft nach den gleichen Regeln.]\n")
            WARTEN3()
            print("[Um den Gegner zu besiegen, muss du ihn gut erwischen. "
                  "Deine Axt ist für diese Aufgabe gut geeignet.]\n")
            WARTEN3()
            print("[Allerdings verbraucht sie auch mehr Ausdauer als, sagen wir, "
                  "das Messer, das der Ork in der Hand hält.]\n")
            WARTEN3()
            print("[Und jedes halbwegs schlaue Lebewesen weiß: Orks haben eine höhere Ausdauer als Menschen.]\n")
            WARTEN3()
            print("[Dabei hast du noch Glück, dass er keine Rüstung trägt - "
                  "sie würde ihn nämlich einigermaßen schützen.]\n")
            WARTEN3()
            print("[Und wo wir gerade von Schutz und Verteidigung sprechen: Deine Axt ist sperrig und schwer, "
                  "sodass du dich damit nicht so gut bewegen kannst und damit leichter zu treffen bist.]\n")
            WARTEN3()
            print("[Das ist schon mal ein Nachteil, den dein Gegner nicht hat. "
                  "Eine andere Waffe hast du aber nicht.]\n")
            WARTEN3()
            print("[Bedenke das, wenn du dir eine Strategie für den Kampf überlegst.]\n")
            WARTEN3()
            print(f"[Und damit legen wir dann los.]{Fore.GREEN}\n")
            while True:
                befehl = input("Gib bitte \"weiter\" ein, um fortzufahren.\n > ").lower()
                if befehl == "weiter":
                    return
                else:
                    HOPPLA()
        if "nein" in befehl:
            WARTEN2()
            print(f"{Fore.WHITE}[Gut, dann gehen wir davon aus, dass du diese bereits kennst. "
                  f"Nervige Tutorials können wir also überspringen.]{Fore.GREEN}\n")
            WARTEN2()
            while True:
                befehl = input("Gib bitte \"weiter\" ein, um fortzufahren. \n > ").lower()
                if befehl == "weiter":
                    WARTEN2()
                    return
                else:
                    HOPPLA()
        else:
            HOPPLA()


def szene_dialog1():
    print("Du gehst einen Schritt auf die Entführer zu und stellt sie zur Rede.\n")
    WARTEN2()
    print("Was soll dieses Kurzling-Theater hier?!\n")
    WARTEN2()
    print(f"Was um {Fore.YELLOW}Národs{Fore.GREEN} Willen geht hier vor?\n")
    WARTEN2()
    print("Die Antwort fällt nicht sehr verständlich aus, aber du begreifst die wichtigen Dinge.\n")
    WARTEN2()
    print("Sie bereiten ein Opferritual vor.\n")
    WARTEN2()
    print("Es ist für irgendeinen orkischen Gott, dessen Namen du dir nicht gemerkt hast.\n")
    WARTEN2()
    print("Den Zweck verstehst du aber:\n")
    WARTEN2()
    print("Wessin ist eifersüchtig auf deine Wolle, das hast du schon immer gewusst.\n")
    WARTEN2()
    print("Seit er ins Dorf gezogen ist, konntest du dich seiner Blicke auf Dolly nicht erwehren.\n")
    WARTEN2()
    print("Jetzt will er sie opfern, um seinen Schafen die gleiche Fluffigkeit zu verleihen.\n")
    WARTEN2()
    print("Würde das denn helfen? Religion war nie deine Stärke.\n")
    WARTEN2()
    print("Du warst immer vielmehr damit beschäftigt, den Bauernhof am Laufen zu halten.\n")
    WARTEN2()
    print("Überlegungen geistlicher Natur muss man sich leisten können.\n")
    WARTEN2()
    print("Diesen Luxus hast du nicht.\n")
    WARTEN2()
    print("Dieser Giftzwerg, Wessin, offenbar schon.\n")
    WARTEN2()
    print("Kein Wunder, dass sich sein Bauernhof gerade noch so über Wasser halten kann.\n")
    WARTEN2()
    print("Aber das spielt sowieso keine Rolle. Wessin und sein Ork-Söldner sind zu weit gegangen.\n")
    WARTEN2()
    print("Du könntest ihnen natürlich eine letzte Warnung aussprechen. Aber ob sie etwas bringen würde?\n")
    WARTEN2()
    print("Ansonsten bleibt dir nur, Dolly mit Gewalt zu befreien.\n")
    WARTEN2()
    print("Die Beiden haben dir zwar schon einen Rückzieher angeboten, aber das ist keine Option.\n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: überreden, angreifen)\n > ").lower()
        if "greif" in befehl:
            WARTEN2()
            print("Nach kurzer Überlegung zum Schluss, dass du viel zu lange überlegst.\n")
            WARTEN2()
            print("Wessin ist wahrlich zu weit gegangen. Das ist Wahnsinn!\n")
            WARTEN2()
            print("Du hattest eine leise Hoffnung, dass das hier noch gewaltlos ausgeht.\n")
            WARTEN2()
            print("Aber du hast schwere Arbeit noch nie gescheut. Die Beiden kommen hier NICHT mehr lebend raus.\n")
            WARTEN2()
            print("Du umklammerst deine Axt und stürmst auf den Ork zu.\n")
            return
        elif "rede" in befehl:
            WARTEN2()
            print("Du hast zwar noch nie schwere Arbeit gescheut.\n")
            WARTEN2()
            print("Wenn es aber eine Möglichkeit gibt, Dolly ohne Blutvergießen zurückzuholen, "
                  "dann willst du es versuchen.\n")
            WARTEN2()
            print("Also sagst du es noch einmal deutlich:\n")
            WARTEN2()
            print("Dolly ist der Stolz deines Bauernhofs.\n")
            WARTEN2()
            print("Ja, auch deine Einnahmequelle.\n")
            WARTEN2()
            print("Aber auch gewissermaßen ein Familienmitglied.\n")
            WARTEN2()
            print("Vielleicht kannst du die Beiden besiegen, vielleicht auch nicht.\n")
            WARTEN2()
            print("Aber du würdest lieber hier im Kampf sterben, als Dolly im Stich zu lassen.\n")
            WARTEN2()
            print("Du bist dir plötzlich nicht mehr sicher, dass du damit nur Dolly meinst.\n")
            WARTEN2()
            print("Alte Erinnerungen blitzen wieder vor deine Augen auf.\n")
            WARTEN2()
            print("Maika...\n")
            WARTEN2()
            print("Damals hast du versagt, in ebendieser Höhle.\n")
            WARTEN2()
            print("Diese Erinnerung hat dich schon immer geplagt.\n")
            WARTEN2()
            print("Nun gibt sie dir aber überraschend Kraft.\n")
            WARTEN2()
            print("Keinen Schritt zurück! So viel steht für dich fest.\n")
            WARTEN3()
            print(f"{Fore.WHITE}[Nun sind deine Überredungskünste gefragt.]\n")
            WARTEN2()
            print("[Als einfacher Bauer ist Überzeugen eigentlich nicht deine Stärke.]\n")
            WARTEN2()
            print("[Der Einsatz von ungeübten Fertigkeiten wird normalerweise von einem Malus begleitet.]\n")
            WARTEN2()
            print("[Als tierlieber Mensch legst du aber immerhin eine gewisse Empathie an den Tag.]\n")
            WARTEN2()
            print("[Diese wird dir einen kleinen Bonus auf den Wurf bescheren.]\n")
            WARTEN2()
            while True:
                befehl = input("Gib nun \"würfeln\" ein, um den Überredungsversuch zu starten.\n > ").lower()
                if befehl == "würfeln":
                    WARTEN2()
                    wurf_ueberreden = olig.wurf_ueberreden(12)
                    WARTEN2()
                    if wurf_ueberreden == True:
                        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Du hättest zwar nicht damit gerechnet, aber dein Rede scheint den Ork "
                              "beeindruckt zu haben.\n")
                        WARTEN2()
                        print("Diese Ungeheuer sind nicht gerade für Empathie bekannt, "
                              "aber sie respektieren Willensstärke.\n")
                        WARTEN2()
                        print("Der Ork-Söldner erkennt aber deine Entschlossenheit an.\n")
                        WARTEN2()
                        print("Vermutlich könne er dich hier töten, so der Ork. Aber nicht heute.\n")
                        WARTEN2()
                        print("Es komme selten vor, dass er einen Menschen mit dem Mut eines Orks treffe.\n")
                        WARTEN2()
                        print("Sein Auftrag sei ohnehin nur die Entführung gewesen.\n")
                        WARTEN2()
                        print("Diesen habe er erfüllt, das Geld sei kassiert.\n")
                        WARTEN2()
                        print("Drama sei langweilig, die Sache könnt ihr unter euch ausmachen.\n")
                        WARTEN2()
                        print("Und damit entfernt sich der Ork vom Tatort.\n")
                        WARTEN2()
                        print("Du lässt ihn vorbei. Scheinbar gibt es selbst unter Orks so etwas wie Ehre.\n")
                        WARTEN2()
                        return True
                    else:
                        WARTEN2()
                        print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Natürlich stoßen deine Worte auf taube Ohren.\n")
                        WARTEN2()
                        print("Nicht, dass es überraschend wäre.\n")
                        WARTEN2()
                        print("Wessin ist fest entschlossen, das Ritual durchzuführen.\n")
                        WARTEN2()
                        print("Der Ork dagegen ist ein Söldner. Ihm geht es nur ums Geld.\n")
                        WARTEN2()
                        print("Leider kannst du ihn bezahlen. Geschweige denn Wessin überbieten.\n")
                        WARTEN2()
                        if olig.edelsteine == False:
                            print("Ohne Blutvergießen wird es also nicht gehen.\n")
                            WARTEN2()
                            print("Du machst dich bereit zum Kampf.\n")
                            WARTEN2()
                            return
                        else:
                            print(f"{Fore.YELLOW}[Edelsteine: Ja]{Fore.GREEN} \n")
                            WARTEN2()
                            print("Oder vielleicht doch?\n")
                            WARTEN2()
                            print("Du hast doch vorhin ein paar Edelsteine gefunden!\n")
                            WARTEN2()
                            print("Du weißt nicht, was deren Wert ist, "
                                  "aber vielleicht kannst du den Ork damit bezahlen.\n")
                            WARTEN2()
                            while True:
                                befehl = input("Willst du versuchen, den Ork zu bestechen?\n > ").lower()
                                WARTEN2()
                                if "ja" in befehl:
                                    befehl = input("Gib nun \"würfeln\" ein,"
                                                   " um den Überredungsversuch zu starten.\n > ").lower()
                                    if befehl == "würfeln":
                                        WARTEN2()
                                        wurf_ueberreden_2 = olig.wurf_w12() + olig,
                                        WARTEN2()
                                        if wurf_ueberreden_2 == True:
                                            print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                                            WARTEN2()
                                            print("Der Ork schaut einmal auf die Edelsteine, die du ihm zeigst.\n")
                                            WARTEN2()
                                            print("Er ist kurz verwirrt, aber er scheint deren Wert zu kennen.\n")
                                            WARTEN2()
                                            print("Du bietest sie ihm an, wenn er nur weggeht.\n")
                                            WARTEN2()
                                            print("Er denkt kurz nach. Dann nickt er, "
                                                  "nimmt die Steine und verlässt den Tatort.\n")
                                            WARTEN2()
                                            print("Weder Söldner noch Orks haben Ehre, das war dir schon immer klar.\n")
                                            WARTEN2()
                                            print("Geld ist aber eine Sprache, die beide Gruppen verstehen.\n")
                                            olig.edelsteine = False
                                            ork.edelsteine = True  # Fürs Spiel komplett irrelevant,
                                                                    # aber der Vollständigkeit halber. :D
                                            return True
                                        elif wurf_ueberreden_2 == 1:
                                            print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
                                            WARTEN2()
                                            print("Der Ork schaut einmal auf die Edelsteine, die du ihm zeigst.\n")
                                            WARTEN2()
                                            print("Er ist kurz verwirrt, aber er scheint deren Wert zu kennen.\n")
                                            WARTEN2()
                                            print("Du bietest sie ihm an, wenn er nur weggeht.\n")
                                            WARTEN2()
                                            print("Er denkt kurz nach. "
                                                  "Dann nickt er, und scheint auf den Angebot einzugehen.\n")
                                            WARTEN2()
                                            print("Als er die Steine in die Hand nehmen will, "
                                                  "greift er jedoch blitzschell nach seinem Messer.\n")
                                            WARTEN2()
                                            print("Er versucht, ihn dir direkt zwischen die Rippen zu bohren.\n")
                                            WARTEN2()
                                            ork_angriff = ork.wurf_w12() + ork.geschick + ork.angriffsbonus
                                            print(f"Überraschnungsangriff: {ork_angriff}\n")
                                            WARTEN2()
                                            if ork_angriff >= olig.verteidigung:
                                                print("Du siehst den Angriff kommen, "
                                                      "kannst aber nicht mehr rechtzeitig reagieren.\n")
                                                WARTEN2()
                                                ork_schaden = random.randint(1, 4)
                                                olig.lebenskraft -= ork_schaden
                                                print(f"Der ehrlose Bastard erwischst dich und verletzt dich um "
                                                      f"{ork_schaden} Punkte Stichschaden.\n")
                                                WARTEN2()
                                                print(f"{Fore.WHITE}[Deine Lebenskraft: "
                                                      f"[{olig.lebenskraft}/{olig.max_lebenskraft}]{Fore.GREEN}\n")
                                                WARTEN2()
                                                print("Verletzt springst du reflexartig zurück.\n")
                                                WARTEN2()
                                                print("Deine Brust schmerzt so stark, dass du dir am liebsten "
                                                      "die Seele aus dem Leib schreien würdest.\n")
                                                WARTEN2()
                                                print("Dein Herz hat er aber zum Glück verfehlt.\n")
                                                WARTEN2()
                                                print("Jetzt ist klar: Nur einer von euch wird "
                                                      "diese Höhle lebend verlassen.\n")
                                                WARTEN2()
                                                print("Du klammerst dich an deine zweihändige Axt und "
                                                      "machst dich bereit zum Kampf.\n")
                                                return
                                            else:
                                                print("Zum Glück kannst du den Angriff kommen sehen und "
                                                      "kannst gerade noch einen Schritt zurück machen.\n")
                                                WARTEN2()
                                                print("So eine Hinterlist! "
                                                      "Haben Ork-Söldner nicht mal einen Tropfen Anstand?\n")
                                                WARTEN2()
                                                print("Jetzt ist dir absolut klar: "
                                                      "Nur einer von euch wird diese Höhle lebend verlassen.\n")
                                                WARTEN2()
                                                print("Du klammerst dich an deine zweihändige Axt "
                                                      "und machst dich bereit zum Kampf.\n")
                                                WARTEN2()
                                                return
                                        else:
                                            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                                            WARTEN2()
                                            print("Der Ork schaut einmal auf die Edelsteine, die du ihm zeigst.\n")
                                            WARTEN2()
                                            print("Er ist kurz verwirrt, aber er scheint deren Wert zu kennen.\n")
                                            WARTEN2()
                                            print("Du bietest sie ihm an, wenn er nur weggeht.\n")
                                            WARTEN2()
                                            print("Er denkt kurz nach. Dann sagt er, dein Angebot sei gut.\n")
                                            WARTEN2()
                                            print("Aber warum würde er darauf eingehen, "
                                                  "wenn er die Steine doch auch von einer Leiche nehmen könne?\n")
                                            WARTEN2()
                                            print("Tja..."
                                                  " Weder Söldner noch Orks wissen, was Ehre ist. "
                                                  "Das war dir schon immer klar.\n")
                                            WARTEN2()
                                            print("Ohne Blutvergießen wird es also nicht gehen.\n")
                                            WARTEN2()
                                            print("Du machst dich bereit zum Kampf.\n")
                                            WARTEN2()
                                            return
                                elif "nein" in befehl:
                                    print("Nein. Diese Blöße wirst du dich nicht geben.\n")
                                    WARTEN2()
                                    print("Ohne Blutvergießen wird es also nicht gehen.\n")
                                    WARTEN2()
                                    print("Du machst dich bereit zum Kampf.\n")
                                    WARTEN2()
                                    return
                                else:
                                    HOPPLA()
                else:
                    HOPPLA()
        else:
            HOPPLA()


def szene2_bosskampf():
    WARTEN2()
    while True:
        befehl = input("Wie willst du dem Ork den Garaus geben?\n("
                       "Optionen: Kopfschlag, Enthauptung, Seitenhieb, Bauchhieb, Verstümmelung mit Überlebensschance, "
                       "bewusstlos schlagen)\n > ").lower()
        if "kopf" in befehl:
            WARTEN2()
            print("Du holst aus und rammst deine mächtige Axt in den Orkschädel, "
                  "begleitet von einem lauten Knacken und einem ekeligen nassen Geräusch.\n")
            WARTEN3()
            print("Der Ork sackt zappelnd zusammen, "
                  "fällt auf den Boden und erstarrt in einer Lache aus seinem eigenen Blut.\n")
            WARTEN3()
            print("Genauer musst du nicht hinsehen. \n")
            WARTEN3()
            print("Als Bauer hast du genug Tiere geschlachtet, um zu wissen, wie sein Kopf jetzt aussieht.\n")
            WARTEN3()
            return True
        elif "haupt" in befehl:
            WARTEN2()
            print("Du erkennst eine Öffnung in seiner Verteidigung.\n")
            WARTEN3()
            print("Du holst aus und schwingst dort, wo du seinen Hals treffen willst.\n")
            WARTEN3()
            print("Zu deiner eigenen Überraschung schlägt ihm der Angriff direkt den Kopf ab...\n")
            WARTEN3()
            print("begleitet von einem ekeligen nassen Geräusch und schwachen Blutspritzern, "
                  "sie aus seinem Hals schnellen.\n")
            WARTEN3()
            print("Der Kopf des Orks fliegt irgendwohin, du kannst diese Stelle nicht ausmachen.\n")
            WARTEN3()
            print("Nicht, dass du wirklich danach suchen würdest.\n")
            WARTEN3()
            print("Der Körper steht noch ein paar Sekunden da, dann fällt er blutend zu Boden.\n")
            WARTEN3()
            return True
        elif "seite" in befehl:
            WARTEN2()
            print("Du erkennst eine günstige Gelegenheit und rammst deine mächtige Axt in die Seite des Orks.\n")
            WARTEN3()
            print("Der Ork stößt Luft aus, als wäre sie ihm einfach so aus den Lungen gewichen.\n")
            WARTEN3()
            print("Er schaut dich an, verwundert.\n")
            WARTEN3()
            print("Er hat ganz offensichtlich nicht damit gerechnet, sein Ende auf diese Weise zu finden.\n")
            WARTEN3()
            print("Der Ork steht kurz da und hält sich an der Seite, dann fällt er zu Boden, "
                  "während sich unter ihm eine Blutlache ausbreitet.\n")
            WARTEN3()
            print("Er streckt seine Hand nach dir aus, als würde er zurückschlagen wollen.\n")
            WARTEN3()
            print("Aber du hast als Bauer genug Tiere geschlachtet und versorgt, um zu wissen, "
                  "dass er nichts mehr macht.\n")
            WARTEN3()
            print("Was immer seine letzten Anstrengungen sind: Sie sind vergeblich.\n")
            WARTEN3()
            print("Die einzige Frage, die sich stellt, ist nur, "
                  "ob du ihm Gnade walten und ihn von seinen Schmerzen erlösen willst.\n")
            WARTEN3()
            while True:
                befehl = input("Willst du dem Ork Gnade walten lassen? (Optionen: Ja, Nein) \n > ").lower()
                if befehl == "ja":
                    WARTEN3()
                    print("Ja. Du bist Vieles, aber nicht grausam.\n")
                    WARTEN3()
                    print("So viel kannst du für den besiegten Feind noch tun.\n")
                    WARTEN3()
                    print("Ein Schlag. Schnell. Sauber. Schmerzlos.\n")
                    WARTEN3()
                    print("Ein Schlag, und der Ork erstarrt.\n")
                    WARTEN3()
                    return True
                if befehl == "nein":
                    WARTEN3()
                    print("Nein. Nicht nach allem, was hier passiert ist.\n")
                    WARTEN3()
                    print("Wie so Vieles auf dieser Welt, ist Gnade ein Luxus.\n")
                    WARTEN3()
                    print("Für dieses Ungeheuer kannst du keine erübrigen.\n")
                    WARTEN3()
                    print("Du wendest dich ab von dem krächszenden Ork und überlässt ihn seinem Schicksal.\n")
                    WARTEN3()
                    return True
                else:
                    HOPPLA()
        elif "bauch" in befehl:
            WARTEN2()
            print("Du erkennst eine günstige Gelegenheit und rammst deine mächtige Axt in den Bauch des Orks.\n")
            WARTEN3()
            print("Der Ork stößt Luft aus, als wäre sie ihm einfach so aus den Lungen gewichen.\n")
            WARTEN3()
            print("Er schaut dich an, verwundert.\n")
            WARTEN3()
            print("Er hat ganz offensichtlich nicht damit gerechnet, sein Ende auf diese Weise zu finden.\n")
            WARTEN3()
            print("Der Ork steht kurz da und hält sich am Bauch, dann fällt er zu Boden, "
                  "während sich unter ihm eine Blutlache ausbreitet.\n")
            WARTEN3()
            print("Er streckt seine Hand nach dir aus, als würde er zurückschlagen wollen.\n")
            WARTEN3()
            print("Aber du hast als Bauer genug Tiere geschlachtet und versorgt, um zu wissen, "
                  "dass er nichts mehr macht.\n")
            WARTEN3()
            print("Was immer seine letzten Anstrengungen sind: Sie sind vergeblich.\n")
            WARTEN3()
            print("Die einzige Frage, die sich stellt, ist nur, ob du ihm Gnade walten und ihn von seinen "
                  "Schmerzen erlösen willst.\n")
            WARTEN3()
            while True:
                befehl = input("Willst du dem Ork Gnade walten lassen?\n > ").lower()
                if befehl == "ja":
                    WARTEN3()
                    print("Ja. Du bist Vieles, aber nicht grausam.\n")
                    WARTEN3()
                    print("So viel kannst du für den besiegten Feind noch tun.\n")
                    WARTEN3()
                    print("Ein Schlag. Schnell. Sauber. Schmerzlos.\n")
                    WARTEN3()
                    print("Ein Schlag, und der Ork erstarrt.\n")
                    WARTEN3()
                    return True
                if befehl == "nein":
                    WARTEN3()
                    print("Nein. Nicht nach allem, was hier passiert ist.\n")
                    WARTEN3()
                    print("Wie so Vieles auf dieser Welt, ist Gnade ein Luxus.\n")
                    WARTEN3()
                    print("Für dieses Ungeheuer kannst du keine erübrigen.\n")
                    WARTEN3()
                    print("Du wendest dich ab von dem krächszenden Ork und überlässt ihn seinem Schicksal.\n")
                    WARTEN3()
                    return True
                else:
                    HOPPLA()
        elif "stümmel" in befehl:
            WARTEN2()
            print("Du erkennst eine Schwäche in der Verteidigung des Orks.\n")
            WARTEN3()
            print("Du könntest ihn jetzt mit einem gut platzierten Schlag töten.\n")
            WARTEN3()
            print("Aber es ist nicht sein Leben, das du willst.\n")
            WARTEN3()
            print("Allerdings kannst du es auch nicht zulassen, dass er dir in den Rücken fällt.\n")
            WARTEN3()
            print("Also schlägst du ihm stattdessen ein Bein ab.\n")
            WARTEN3()
            print("Der Schmerz ist zu viel für den stark verletzten Feind.\n")
            WARTEN3()
            print("Er wird bewusstlos und fällt zu Boden, während sich unter ihm eine Blutlache ausbreitet.\n")
            WARTEN3()
            print("Wenn du nichts tust, wird er verbluten.\n")
            WARTEN3()
            print("Sein Tod würde aber nichts bringen.\n")
            WARTEN3()
            print("Du nimmst dein Fackel und brennst seine Wunde schnell aus.\n")
            WARTEN3()
            print("Vielleicht wird er trotzdem hier sterben, vielleicht auch nicht.\n")
            WARTEN3()
            print("Verbluten wird er hier aber schon mal nicht.\n")
            WARTEN3()
            print("Sein Schicksal ist jetzt in den Händen der Götter.\n")
            WARTEN3()
            print("Und zum Teil auch in seinen eigenen.\n")
            WARTEN3()
            return True
        elif "bewusst" in befehl:
            WARTEN2()
            print("Du erkennst eine Schwäche in der Verteidigung des Orks.\n")
            WARTEN3()
            print("Du könntest ihn jetzt mit einem gut platzierten Schlag töten.\n")
            WARTEN3()
            print("Aber es ist nicht sein Leben, das du willst.\n")
            WARTEN3()
            print("Du schickst dich an, und verpasst ihm einen Schlag auf den Hinterkopf, "
                  "mit der stumpfen Seite deiner Axt.\n")
            WARTEN3()
            print("Der Ork grunzt einmal, dann wird er bewusstlos und fällt zu Boden.\n")
            WARTEN3()
            print("Vermutlich wird bald wieder aufwachen.\n")
            WARTEN3()
            print("Vorerst ist er aber außer Gefecht.\n")
            WARTEN3()
            print("Du hoffst, dass er es spätestens jetzt besser weiß, "
                  "als sich noch einmal in diese Gegend zu trauen.\n")
            WARTEN3()
            return
        else:
            HOPPLA()
