from charaktere import *


def raum_suedkorridor1():
    print(f"{Fore.WHITE}[Du befindest dich im südlichen Gang.]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Gang windet sich schlangenartig, scheinbar unendlich lange.\n")
    WARTEN2()
    print("Zunächst siehst du ein paar Malereien, Moosbestände und andere Zeichen von vergangenen Höhlenbesuchen.\n")
    WARTEN2()
    print("Doch je weiter du dem Gang folgst, desto seltener werden diese Spuren.\n")
    WARTEN2()
    print("Bis irgendwann nichts mehr übrig bleibt, nur nacktes und lebloses Gestein.\n")
    WARTEN2()
    print("Langsam kommst es dir vor, als sei das Leben hier völlig zum Stillstand gekommen.\n")
    WARTEN2()
    print("Verloren in der Zeit.\n")
    WARTEN2()
    print("Verloren im Raum.\n")
    WARTEN2()
    print("Vielleicht auch einfach nur verloren.\n")
    WARTEN2()
    print("Der Tunnel führt noch eine Weile weiter.\n")
    WARTEN2()
    print("Irgendwann stolperst du beinahe über eine Leiche.\n")
    WARTEN2()
    print("Dem Zustand nach ist liegt sich schon eine ganze Weile hier.\n")
    while True:
        frage = input("Willst du dir die Leiche genauer anschauen?\n > ").lower()
        if "ja" in frage:
            raum_suedkorridor1_ruestung()
            break
        elif "nein" in frage:
            print("Du entscheidest dich dafür, die Toten ruhen zu lassen und gehst noch eine Weile weiter.\n")
            break
        else:
            HOPPLA()
            continue
    WARTEN2()
    print("Plötzlich musst du anhalten.\n")
    WARTEN2()
    print("Vor dir erstreckt sich ein riesiges Loch.\n")
    WARTEN2()
    print("Du schaust in die Dunkelheit unter dir, entdeckst aber nichts außer der schwarzen Leere.\n")
    WARTEN2()
    print("Mehr noch: Du bekommst das Gefühl, dass die Dunkelheit vielmehr dich betrachtet als du sie.\n")
    WARTEN2()
    print("Auf der anderen Seite führt der Gang weiter.\n")
    WARTEN2()
    print("Du siehst keine Möglichkeit, das Loch zu überwinden... Außer, du springst.\n")
    WARTEN2()
    print("So haben die Übeltäter Dolly natürlich ganz sicher nicht geführt.\n")
    WARTEN2()
    print("Aber wer weiß, was auf der anderen Seite ist?\n")
    WARTEN2()
    print("Du rechnest einmal kurz deine Chancen aus und kommst zu dem Schluss, "
          "dass du das Loch überspringen könntest.\n")
    WARTEN2()
    print("Wenn du Glück hast.\n")
    WARTEN2()
    print("Das ist nicht ideal, aber ansonsten bleibt dir nur der ganze Weg zurück zur Kreuzung.\n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: springen, zurückgehen)\n > ").lower()
        if "gehe" in befehl or "zurück" in befehl:
            return "gehe"
        elif "spring" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_suedkorridor1_ruestung():
    WARTEN2()
    print("Außer dem Skelett ist von ihr nichts mehr übrig.\n")
    WARTEN2()
    print("Du bist dir nicht sicher, wer das gewesen sein könnte.\n")
    WARTEN2()
    print("Solche Vorfälle gibt es hier in der Gegend nur selten.\n")
    WARTEN2()
    print("Das letzte Mal wird das wohl bei der einen Sache mit den Orks gewesen sein.\n")
    WARTEN2()
    print("Uralt kann das Skelett aber auch nicht sein. Es hat noch eine Textilrüstung an, scheinbar noch im guten "
          "- oder zumindest brauchbar - Zustand.\n")
    WARTEN2()
    print("Da wärst du fast versucht, sie anzuprobieren.\n")
    WARTEN2()
    print("Die Toten auf diese Weise zu stören ist wahrlich eine undankbare angelegenheit. Dass es taktlos ist, davon "
          "fängst du lieber gar nicht erst an.\n")
    WARTEN2()
    print("Andererseits wurde die hier nicht ordentlich begraben, geschweige denn gesegnet. Du würdest also nicht "
          "gerade die Totenruhe stören.\n")
    WARTEN2()
    print("Und wenn deine Vermutung stimmt, könntest du sie gut gebrauchen.\n")
    WARTEN2()
    print("Du hast gesehen, wie gefährlich Orks sein können. Bessere Ausrüstung könnte da sicherlich nicht schaden.\n")
    WARTEN2()
    while True:
        frage = input("Willst du mehr über Rüstungen erfahren?\n > ").lower()
        if "ja" in frage:
            print(f"{Fore.WHITE}[Rüstungen bieten einem Charakter zusätzlichen Schutz gegen potentielle Schläge.\n")
            WARTEN2()
            print("[Wie auch im echten Mittelalter, ist der Kampf in der Welt von \"Zeit der Zünfte\" "
                  "brutal und tödlich.]\n")
            WARTEN2()
            print("Der beste Schutz ist also, gar nicht erst getroffen zu werden.]\n")
            WARTEN2()
            print("[Ausweichen, Parieren und Blocken sind Kampfmanöver sind lebensentscheidend.]\n")
            WARTEN2()
            print("[Als Bauer hast du natürlich nichts davon wirklich gelernt. "
                  "Raufereien und kleine Schlägereien zählen nur minimal.]")
            WARTEN2()
            print("[Der Schild ist die nächstbeste Verteidigung. Aber den hast du nicht.]\n")
            WARTEN2()
            print("[Und wenn alles Andere versagt, soll die Rüstung einem als eine letzte Chance dienen.]\n")
            WARTEN2()
            print("[Solange sie standhält und nicht durchbrochen wird, heißt das.\n]")
            WARTEN2()
            print("[In Anbetracht dessen, was über die Verteidigung gesagt wurde, eine Sache vorweg:]\n")
            WARTEN2()
            print("[Rüstungen werden so entworfen und hergestellt, dass sie den Träger möglichst wenig behindern.]\n")
            WARTEN2()
            print("[Du wirst also nicht leichter zu treffen sein, wenn du eine Rüstung trägst.]\n")
            WARTEN2()
            print("Allerdings wiegt eine Rüstung auch Einiges, und seien es \"nur ein paar Schichten Leinen\" "
                  "(und nein, eine Textilrüstung ist nicht unbedingt schlechter als Leder oder Eisen).]\n")
            WARTEN2()
            print("[Kurzgefasst: Eine Rüstung schützt den Träger bis zu einem gewissen Grad vor einem tödlichen Schlag,"
                  " ist aber auch nicht gerade leicht und erfordert mehr Krafteinsatz, um sich darin zu bewegen.]\n")
            WARTEN2()
            print("[Diese Belastung wirkt sich auf deinen körperlichen Einsatz und - sollte es denn zu einem Kampf "
                  "kommen - deine Ausdauer. Was das hei0t, erfährst, falls und wenn es soweit ist.]\n")
            WARTEN2()
            print("[Für den Moment reicht es, zu wissen, dass es eine gute Idee ist, "
                  "im Kampf eine Kraftreserve zu haben.\n")
            WARTEN2()
            print("[Jede Rüstung hat also ihr Für und Wider.]\n")
            WARTEN2()
            print(f"[Und mit diesem Wissen im Hinterkopf...]{Fore.GREEN}\n")
            break
        elif "nein" in frage:
            break
        else:
            HOPPLA()
            continue
    while True:
        frage = input("Willst du die Textilrüstung anziehen? \n > ").lower()
        if "ja" in frage or "will" in frage:
            olig.panzerung = ruestung_textil
            print("Du atmest einmal tief durch und machst dich ans unangenehme Werk.\n")
            WARTEN2()
            print("Es ist ekelig und irgendwie entwürdigend, aber du hast auf deinem Bauernhof schon "
                  "Schlimmeres erlebt.\n")
            WARTEN2()
            print("Etwas ungeschickt ziehst du dem Skelett die Rüstung aus (an der zum Glück kein Gewebe "
                  "mehr dran ist) und ziehst sie an.\n")
            WARTEN2()
            print("Sie wurde eindeutig nicht für deine Größe gemacht.\n")
            WARTEN2()
            print("Sie ist schwer, etwas klein und riecht wirklich nach alten Stoffen.\n")
            WARTEN2()
            print("Für einige Stunden wird es aber schon passen (müssen).\n")
            WARTEN2()
            print("Du rückst sie zurecht - soweit es eben möglich ist - und gehst noch eine Weile weiter.\n")
            WARTEN2()
            return
        elif "nein" in frage or "nicht" in frage:
            print("Du denkst einmal scharf darüber nach, die Rüstung anzuziehen, entscheidest dich schließlich "
                  "aber dagegen.\n")
            WARTEN2()
            print("Du bist eben Bauer, kein Krieger, und hast mit so etwas keine Erfahrung.\n")
            WARTEN2()
            print("Vielleicht würde sie dich nur behindern, vielleicht auch nicht."
                  " Du bleibst jedenfalls lieber bei dem, as du kennst.\n")
            WARTEN2()
            print("Du verwirfst den Gedanken an die Rüstung, lässt das Skelett weiter liegen "
                  "und gehst noch eine Weile weiter.")
            return
        else:
            HOPPLA()


def raum_suedkorridor1_wurf():
    print(f"{Fore.WHITE}[Nun brauchen wir wieder einen Wurf, um zu sehen, ob du den Sprung schaffst.]\n")
    WARTEN2()
    print("[Dieses Mal testen wir also dein Geschick.]\n")
    WARTEN2()
    print("[Gut, eigentlich wäre der Wurf für die Fertigkeit \"Sportlichkeit\".]\n")
    WARTEN2()
    print("[Als einfacher Bauer hast du diese allerdings nicht trainiert.]\n")
    WARTEN2()
    print(f"[Dein Geschick-Bonus muss also reichen.]{Fore.GREEN}\n")
    WARTEN2()
    befehl = input("Gib nun bitte 'würfeln' ein.\n > ").lower()
    WARTEN2()
    if "würfeln" in befehl:
        wurf_sportlichkeit = olig.wurf_sportlichkeit(14)
        if wurf_sportlichkeit == True:
            print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
            WARTEN2()
            print("Du nimmst Anlauf und springst.\n")
            WARTEN2()
            print("Das Loch war breiter als gedacht, aber zum Glück kommst gut auf der anderen Seite an.\n")
            WARTEN2()
            print("Du schaust dich um. Auf dem gleichen Wege kommst du schon mal nicht zurück, "
                  "selbst wenn du Dolly findest.\n")
            WARTEN2()
            print("Es bleibt dir also nichts Anderes übrig, als weiterzugehen.\n")
            return True
        elif wurf_sportlichkeit in range(2, 14):
            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
            WARTEN2()
            print("Du nimmst Anlauf und springst.\n")
            WARTEN2()
            print("Das Loch ist breiter als gedacht.\n")
            print("Das Loch ist breiter als gedacht.\n")
            WARTEN2()
            print("Du verschätzt dich knapp und fällst runter.\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Nun hast du deinen Fertigkeitswurf nicht bestanden.]\n")
            WARTEN2()
            print("[Das ist eindeutig suboptimal, aber noch ist nicht alles verloren.]\n")
            WARTEN2()
            print("[Dafür sieht das Spielsystem Rettungs- und Glückswürfe vor.] \n")
            WARTEN2()
            print("[Schaffst du den Rettungswurf, kannst du gerade noch so den Rand auf der anderen Seite greifen "
                  "und dich hochziehen.]\n")
            WARTEN2()
            print("[Verfehlst du nur ganz knapp, dann hast du den Glückswurf geschafft und kannst "
                  "zumindest das Schlimmste verhindern.]\n")
            WARTEN2()
            print("[Und ansonsten... Nun ja, es hat dich ja niemand gezwungen, "
                  "einfach drauf loszuspringen, nicht wahr?] \n")
            WARTEN2()
            print(f"[Zum Glück hast du als Bauer ziemlich starke Arme und Beine. "
                  f"Deine Chancen stehen also gar nicht mal so schlecht.]{Fore.GREEN}\n")
            WARTEN2()
            while True:
                befehl = input("Gib nun \"würfeln\" ein. \n > ").lower()
                if "würfeln" in befehl:
                    wurf_reflex = olig.reflexwurf(14)
                    if wurf_reflex == True:
                        print(f"{Fore.BLUE}[ERFOLG: RETTUNGSWURF]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Zum Glück war Sprung gut genug, dass es fast geschafft hast.\n")
                        WARTEN2()
                        print("Du kommst zwar nicht auf der anderen Seite an, "
                              "kannst aber den Felsboden fest mit beiden Händen greifen.\n")
                        WARTEN2()
                        print("Du ziehst sich hoch und schaust dich um.\n")
                        WARTEN2()
                        print("Auf dem gleichen Wege kommst du schon mal nicht zurück, selbst wenn du Dolly findest.\n")
                        WARTEN2()
                        print("Es bleibt dir also nichts Anderes übrig, weiterzugehen.\n")
                        WARTEN2()
                        return True
                    elif wurf_reflex in range(12, 14):
                        print(f"{Fore.BLUE}[ERFOLG: GLÜCKSWURF]{Fore.GREEN}\n")
                        WARTEN2()
                        print("Zum Glück war der Sprung gut genug, dass du es fast geschafft hast.\n")
                        WARTEN2()
                        print("Du kommst zwar nicht auf der anderen Seite an, "
                              "kannst aber den Felsboden mit einer Hand greifen.\n")
                        WARTEN2()
                        print("Nun musst es irgendwie schaffen, dich hochzuziehen.\n")
                        WARTEN2()
                        while True:
                            befehl = input("Gib nun \"würfeln\" ein. \n > ").lower()
                            if "würfeln" in befehl:
                                wurf_kraft = olig.kraftwurf(14)
                                if wurf_kraft == True:
                                    print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN}\n")
                                    WARTEN2()
                                    print("Mit etwas Mühe kannst du den Rand des Bodens mit der zweiten Hand greifen "
                                          "und dich mit beiden Händen hochzuziehen.\n")
                                    WARTEN2()
                                    print("Du schaust dich um.\n")
                                    WARTEN2()
                                    print("Auf dem gleichen Wege kommst du schon mal nicht zurück, "
                                          "selbst wenn du Dolly findest.\n")
                                    WARTEN2()
                                    print("Es bleibt dir also nichts Anderes übrig, weiterzugehen.\n")
                                    return True
                                else:
                                    print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN}\n")
                                    WARTEN2()
                                    print("Du versuchst, dich hochzuziehen, doch deine Hand rutscht ab, "
                                          "bevor mit der zweiten nach dem Rand des Boden greifen kannst.\n")
                                    WARTEN2()
                                    print("Du fällst und verschwindest im Loch, "
                                          "auf ewig verloren in der schwarzen Leere.\n")
                                    WARTEN2()
                                    print("Vielleicht werden dir die Götter Gnade walten lassen, "
                                          "die du im Leben nicht kanntest.\n")
                                    WARTEN2()
                                    print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
                                    WARTEN2()
                                    print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
                                    WARTEN2()
                                    print("Ende \n")
                                    WARTEN2()
                                    return False
                            else:
                                HOPPLA()
        else:
            print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
            WARTEN2()
            print("Du nimmst Anlauf und springst, verschätzt dich allerdings und fliegst nicht weit genug.\n")
            WARTEN2()
            print("Du hast dich gerade mal stark genug verschätzt, dass nichts greifen kannst, "
                  "um deinen Fall aufzuhalten.\n")
            WARTEN2()
            print("Du verschwindest im Loch, auf ewig verloren in der schwarzen Leere.\n")
            WARTEN2()
            print("Vielleicht werden dir die Götter Gnade walten lassen, die du im Leben nicht kanntest.\n")
            WARTEN2()
            print("Dein Abenteuer in der Welt der Lebenden ist aber hiermit zu Ende.\n")
            WARTEN2()
            print("Der Lebensfaden abrupt abgeschnitten. Durch den eigenen Fehler.\n")
            WARTEN2()
            print("Ende \n")
            WARTEN2()
            return False
    else:
        HOPPLA()


def raum_suedkorridor2():
    print(f"{Fore.WHITE}[Du folgst dem südlichen Gang.]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Gang führt schließlich zu einer größeren Höhle.\n")
    WARTEN2()
    print("Was du dort erblickst, lässt sich kaum beschreiben.\n")
    WARTEN2()
    print("Du siehst Dolly - angebunden, mitten in einem Kreis aus einer roten Substanz.\n")
    WARTEN2()
    print("Neben dem Kreis erkennst du einen Tisch mit irgendwelchen Werkzeugen.\n")
    WARTEN2()
    print("Das Ganze sieht verdächtig nach einer Art Opfer-Ritual aus.\n")
    WARTEN2()
    print("Den Übeltäter kannst du auch erkennen.\n")
    WARTEN2()
    print("Ein großer schwarzer Ork ist gerade dabei, eine Klinge zu schärfen.\n")
    WARTEN2()
    print("Dieser Bastard!\n")
    WARTEN2()
    print("Arme Dolly! Du musst sie unbedingt da rausholen!\n")
    WARTEN2()
    print("Er scheint sich dabei mit jemandem zu unterhalten, und schon bald siehst du, mit wem.\n")
    WARTEN2()
    print("Einem Zwerg, den du sofort erkennst.\n")
    WARTEN2()
    print("Wessin. Dein Bauernhof-Nachbar.\n")
    WARTEN2()
    print("Was um alles in der Welt passiert hier eigentlich?\n")
    WARTEN2()
    print("Was immer es ist: Die Zeit ist knapp!\n")
    WARTEN2()
    print("Die beiden Übeltäter bemerken dein Licht und schauen dich an.\n")
    WARTEN2()
    print("Jetzt hast du eigentlich nur zwei Optionen:\n")
    WARTEN2()
    print("Du kannst die Entführer natürlich stellen und versuchen, Dolly mit Worten zurückzuholen.\n")
    WARTEN2()
    print("Würden sie darauf hören? Irgendwie hast du da deine Zweifel. Aber man weiß ja nie.\n")
    WARTEN2()
    print("Du kannst natürlich auch deine Axt greifen direkt losschwingen.\n")
    WARTEN()
    print("Je schneller du mit dem Ork fertig wirst, desto besser.\n")
    WARTEN2()
    print("Den Rest kannst du später klären.\n")
    WARTEN2()
    print("Immerhin hast du Glück: Der Ork hat keine Rüstung an. Sein Lederpanzer liegt neben dem Tisch.\n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: reden, angreifen)\n > ").lower()
        if "rede" in befehl:
            return befehl
        elif "greif" in befehl:
            return befehl
        else:
            HOPPLA()
