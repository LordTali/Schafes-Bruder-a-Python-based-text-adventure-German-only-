from waffen import *
from ruestung import *


class Charakter:

    basis_verteidigung = 10

    def __init__(self, name, kraft, geschick, koerperbau, grips, empathie, magie, stufe, klasse, max_ausdauer,
                 ausdauer, zauberkraft, verteidigung, willen, reflexe_bonus, reflexe, widerstand,
                 max_lebenskraft, lebenskraft, initiative_bonus, aktionen_nummer, angriffsbonus, schadensbonus,
                 max_ruestung, ruestung, edelsteine, augen, fertigkeit_sportlichkeit, fertigkeit_ueberreden,
                 fertigkeit_religion, bewaffnung, initiative, panzerung, malus_erschoepfung, schutz):
        self.name = name
        self.kraft = kraft
        self.geschick = geschick
        self.koerperbau = koerperbau
        self.grips = grips
        self.empathie = empathie
        self.magie = magie
        self.stufe = stufe
        self.klasse = klasse
        self.max_ausdauer = self.kraft + self.koerperbau + self.stufe
        self.ausdauer = max_ausdauer
        self.zauberkraft = self.empathie + self.magie + self.stufe
        self.reflexe_bonus = reflexe_bonus
        self.reflexe = self.geschick + self.reflexe_bonus
        self.verteidigung = Charakter.basis_verteidigung + self.reflexe
        self.willen = self.empathie + self.stufe


        self.widerstand = self.willen + self.koerperbau
        self.max_lebenskraft = self.koerperbau + self.stufe
        self.lebenskraft = max_lebenskraft
        self.initiative_bonus = initiative_bonus
        self.aktionen_nummer = aktionen_nummer
        self.angriffsbonus = angriffsbonus
        self.max_ruestung = max_ruestung
        self.ruestung = max_ruestung
        self.edelsteine = edelsteine
        self.augen = augen
        self.fertigkeit_sportlichkeit = fertigkeit_sportlichkeit
        self.fertigkeit_ueberreden = fertigkeit_ueberreden
        self.fertigkeit_religion = fertigkeit_religion
        self.bewaffnung = bewaffnung
        self.initiative = initiative
        self.panzerung = panzerung
        self.malus_erschoepfung = malus_erschoepfung
        self.schutz = self.panzerung.panzerung_torso
        self.schadensbonus = schadensbonus

    def wurf_w6(self):
        wurf = random.randint(1, 6)
        print(f" {Fore.WHITE}[Würfel:{wurf}]{Fore.GREEN}\n")
        return wurf

    def wurf_w8(self):
        wurf = random.randint(1, 8)
        print(f"{Fore.WHITE}[Würfel: {wurf}]{Fore.GREEN}\n")
        return wurf

    def wurf_w12(self):
        wurf = random.randint(1, 12)
        if wurf == 12:
            print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
            WARTEN2()
        print(f"{Fore.WHITE}[Würfel: {wurf}]{Fore.GREEN}\n")
        WARTEN2()
        return wurf

    def ausruesten(self, waffen):
        self.bewaffnung = waffen
        print(f"{self.name} kämpft nun mit: {self.bewaffnung.name}")

    def wurf_erkennen(self, ziel):
        wurf_w12_erkennen = (self.wurf_w12())
        wurf_auf_erkennen = wurf_w12_erkennen + self.augen + int(self.grips / 2)
        print(f"{Fore.WHITE}[Dein Wurf (Erkennen):{wurf_auf_erkennen}]{Fore.GREEN}\n")
        WARTEN2()
        if wurf_auf_erkennen >= ziel or wurf_w12_erkennen == 12:
            return True
        else:
            return wurf_auf_erkennen

    def wurf_koerperbau(self, ziel):
        wurf_w12_koerperbau = (self.wurf_w12())
        koerperbauwurf = wurf_w12_koerperbau + self.koerperbau
        if wurf_w12_koerperbau == 1:
            koerperbauwurf = 1
        print(f"{Fore.WHITE}[Dein Wurf (Körperbau): {koerperbauwurf}]{Fore.GREEN}\n")
        WARTEN2()
        if koerperbauwurf >= ziel or wurf_w12_koerperbau == 12:
            return True
        else:
            return koerperbauwurf

    def kraftwurf(self, ziel):
        wurf_w12_kraft = (self.wurf_w12())
        wurf_auf_kraft = wurf_w12_kraft + self.kraft
        print(f"{Fore.WHITE}[Dein Wurf (Kraft): {wurf_auf_kraft}]{Fore.GREEN}\n")
        WARTEN2()
        if wurf_auf_kraft >= ziel or wurf_w12_kraft == 12:
            return True
        else:
            return wurf_auf_kraft

    def reflexwurf(self, ziel):
        wurf_w12_reflex = (self.wurf_w12())
        wurf_auf_reflexe = wurf_w12_reflex + self.reflexe
        if wurf_w12_reflex == 1:
            wurf_auf_reflexe = 1
        elif wurf_w12_reflex == 12:
            wurf_auf_reflexe = 12
        print(f"{Fore.WHITE}[Dein Wurf (Reflexe): {wurf_auf_reflexe}]{Fore.GREEN}\n")
        WARTEN2()
        if wurf_auf_reflexe >= ziel or wurf_w12_reflex == 12:
            return True
        else:
            return wurf_auf_reflexe

    def wurf_sportlichkeit(self, ziel):
        wurf_w12_sportlichkeit = (self.wurf_w12())
        sportlichkeitswurf = wurf_w12_sportlichkeit + self.fertigkeit_sportlichkeit + int(self.geschick / 2)
        if self.fertigkeit_sportlichkeit == 0:
            sportlichkeitswurf -= 3
        print(f"{Fore.WHITE}[Dein Wurf (Sportlichkeit): {sportlichkeitswurf}]{Fore.GREEN}\n")
        WARTEN2()
        if sportlichkeitswurf >= ziel or wurf_w12_sportlichkeit == 12:
            return True
        else:
            return sportlichkeitswurf

    def wurf_ueberreden(self, ziel):
        wurf_w12_ueberreden = (self.wurf_w12())
        ueberredungswurf = wurf_w12_ueberreden + self.fertigkeit_ueberreden + int(self.empathie / 2)
        if wurf_w12_ueberreden == 1:
            ueberredungswurf = 1
        elif wurf_w12_ueberreden == 12:
            ueberredungswurf = 12
        print(f"{Fore.WHITE}[Dein Wurf (Überreden): {ueberredungswurf}]{Fore.GREEN}\n")
        WARTEN2()
        if ueberredungswurf >= ziel or wurf_w12_ueberreden == 12:
            return True
        else:
            return ueberredungswurf

    def wurf_religion(self, ziel):
        wurf_w12_religion = (self.wurf_w12())
        religionswurf = wurf_w12_religion + self.fertigkeit_religion + int(self.empathie / 2)
        if self.fertigkeit_religion == 0:
            religionswurf -= 3
        print(f"{Fore.WHITE}[Dein Wurf (Religion): {religionswurf}]{Fore.GREEN}\n")
        WARTEN2()
        if religionswurf >= ziel or wurf_w12_religion == 12:
            return True
        else:
            return religionswurf

    def wurf_willen(self, ziel):
        wurf_w12_willen = (self.wurf_w12())
        willenswurf = self.willen + wurf_w12_willen
        print(f"[Dein Wurf (Willen): {Fore.WHITE}{willenswurf}]{Fore.GREEN}\n")
        if willenswurf >= ziel or wurf_w12_willen == 12:
            return True
        else:
            return willenswurf

    def angriff_vorsichtig(self):
        self.angriffsbonus -= 2
        self.verteidigung += 2
        WARTEN2()
        return

    def angriff_aggressiv(self):
        self.angriffsbonus += 2
        self.schadensbonus += 2
        self.verteidigung -= 4
        WARTEN2()
        return

    def angreifen_schnell(self):
        WARTEN2()
        self.angriffsbonus -= 4
        self.verteidigung -= 4
        WARTEN2()
        return

    def schaden(self, ziel):
        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN} \n")
        WARTEN2()
        print(f"{Fore.WHITE}[Tödlichkeit der Waffe ({self.bewaffnung.name}): {self.bewaffnung.toedlichkeit}]{Fore.GREEN}\n")
        WARTEN2()
        print(f"{Fore.WHITE}[Schaden: {self.bewaffnung.schaden}]{Fore.GREEN}\n")
        WARTEN2()
        gesamtschaden = self.bewaffnung.schaden + self.schadensbonus
        print(f"{Fore.WHITE}[Schaden (gesamt): {gesamtschaden}]{Fore.GREEN}\n")
        WARTEN2()
        if ziel.panzerung.name != "Ungerüstet":
            ziel.schutz -= self.bewaffnung.schaden
            if ziel.schutz > 0:
                print(f"{Fore.WHITE}[Rüstung ({ziel.name}): {ziel.schutz}/{ziel.max_schutz}]{Fore.GREEN}\n")
                WARTEN2()
            elif ziel.panzerung == 0:
                ziel.lebenskraft -= self.bewaffnung.schaden
                print(f"{Fore.WHITE}[Die Rüstung bietet keinen Schutz mehr]{Fore.GREEN}\n ")
                WARTEN2()
                print(f"{Fore.WHITE}[Lebenskraft {ziel.name}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                      f"{Fore.GREEN} \n")
                WARTEN2()
            else:
                ziel.lebenskraft = ((ziel.lebenskraft + (ziel.schutz + self.bewaffnung.schaden)) -
                                    self.bewaffnung.schaden)
                print(f"{Fore.WHITE}[Die Rüstung wurde durchbrochen.]{Fore.GREEN} \n")
                WARTEN2()
                print(f"{Fore.WHITE}[Lebenskraft ({ziel.name}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                      f"{Fore.GREEN} \n")
                ziel.schutz = 0
                WARTEN2()
                if ziel.lebenskraft <= 0:
                    print(f"{Fore.WHITE}[{ziel.name} wurde besiegt.]{Fore.GREEN}\n")
                    WARTEN2()
                else:
                    ziel.lebenskraft -= self.bewaffnung.schaden
                    print(f"{Fore.WHITE}[Lebenskraft ({ziel.name}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                          f"{Fore.GREEN} \n")
                    WARTEN2()
                return
        else:
            ziel.lebenskraft -= gesamtschaden
            print(f"{Fore.WHITE}[Lebenskraft {ziel.name}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                  f"{Fore.GREEN} \n")
            WARTEN2()
            if ziel.lebenskraft <= 0:
                print(f"{Fore.WHITE}[{ziel.name} wurde besiegt.]{Fore.GREEN}\n")
                WARTEN2()
            return

class Spieler(Charakter):
    def __init__(self, name, kraft, geschick, koerperbau, grips, empathie, magie, stufe, klasse, max_ausdauer,
                 ausdauer, zauberkraft, verteidigung, willen, reflexe_bonus, reflexe, widerstand,
                 max_lebenskraft, lebenskraft, initiative_bonus, aktionen_nummer, angriffsbonus, schadensbonus,
                 max_ruestung, ruestung, edelsteine, augen, fertigkeit_sportlichkeit, fertigkeit_ueberreden,
                 fertigkeit_religion, bewaffnung, initiative, westgang, panzerung, malus_erschoepfung, schutz):
        super().__init__(name=name, kraft=kraft, geschick=geschick, koerperbau=koerperbau, grips=grips,
                         empathie=empathie, magie=magie, stufe=stufe, klasse=klasse, max_ausdauer=max_ausdauer,
                 ausdauer=ausdauer, zauberkraft=zauberkraft, verteidigung=verteidigung, willen=willen,
                         reflexe_bonus=reflexe_bonus, reflexe=reflexe, widerstand=widerstand,
                 max_lebenskraft=max_lebenskraft, lebenskraft=lebenskraft, initiative_bonus=initiative_bonus,
                         aktionen_nummer=aktionen_nummer, angriffsbonus=angriffsbonus, schadensbonus=schadensbonus,
                 max_ruestung=max_ruestung, ruestung=ruestung, edelsteine=edelsteine, augen=augen,
                         fertigkeit_sportlichkeit=fertigkeit_sportlichkeit, fertigkeit_ueberreden=fertigkeit_ueberreden,
                 fertigkeit_religion=fertigkeit_religion, bewaffnung=bewaffnung, initiative=initiative,
                         panzerung=panzerung, malus_erschoepfung=malus_erschoepfung, schutz=schutz)
        self.westgang = westgang

    def handeln(self, ziel):

        print(f"{Fore.WHITE}[Du bist dran.] {Fore.GREEN}\n")
        WARTEN2()
        while self.aktionen_nummer > 0:
            while True:
                print(f"{Fore.WHITE}[Verbleibende Aktionen: {self.aktionen_nummer}]{Fore.GREEN}\n")
                WARTEN2()
                if ziel.lebenskraft <= 0:
                    befehl ="zug"
                else:
                    befehl = input("Was willst du tun? (Optionen: angreifen, ausweichen, Zug beenden) \n > ").lower()
                if "greif" in befehl:
                    WARTEN2()
                    self.angreifen()
                    break
                elif "weich" in befehl:
                    if self.aktionen_nummer >= 2:
                        self.aktionen_nummer = 0
                        self.verteidigung += 2
                        self.ausdauer -= 1
                        WARTEN2()
                        print(f"{Fore.WHITE}[Du versuchst, dem Angriff des Gegners auszuweichen.]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Bonus (Verteidigung): 2]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
                        WARTEN2()
                        return
                    else:
                        WARTEN2()
                        print(f"{Fore.WHITE}[Du hast in dieser Runde bereits gehandelt, "
                              f"daher kannst du nicht mehr ausweichen. Bitte wähle eine andere Aktion.]{Fore.GREEN}\n")
                        WARTEN2()
                        continue
                elif "zug" in befehl:
                    WARTEN2()
                    print(f"{Fore.WHITE}[Du beendest deinen Zug.]{Fore.GREEN}\n")
                    WARTEN2()
                    if self.aktionen_nummer == 2:
                        if self.ausdauer < self.max_ausdauer:
                            self.ausdauer += 1
                    print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
                    WARTEN2()
                    self.aktionen_nummer = 0
                    return
                else:
                    WARTEN2()
                    print(f"{Fore.WHITE}[Hoppla! An diesem Befehl stimmt etwas nicht. Versuch's bitte noch mal!]"
                          f"{Fore.GREEN}\n")
                    WARTEN2()
                    continue
        else:
            print(f"{Fore.WHITE}[Du kannst in diesem Zug keine Aktionen mehr ausführen.]{Fore.GREEN}\n")
            WARTEN2()
            return

    def angreifen(self):
            ziel = ork
            while True:
                if self.aktionen_nummer >= 2:
                    befehl = input("Wie willst du angreifen? (Optionen: ruhig, aggressiv, vorsichtig) \n > ").lower()

                    if "ruh" in befehl:
                        self.angriff(ziel)
                        break
                    elif "aggr" in befehl:
                        self.angriff_aggressiv()
                        self.angriff(ziel)
                        break
                    elif "vor" in befehl:
                        self.angriff_vorsichtig()
                        self.angriff(ziel)
                        break
                    else:
                        HOPPLA()
                else:
                    print(f"{Fore.WHITE}[Du hast bereits einen Kampfstil für diese Runde verwendet. "
                          f"Dieser bleibt bis zur nächsten Runde erhalten.]{Fore.GREEN}\n")
                    WARTEN2()
                    self.angriff(ziel)
                    break

            return


    def angriff(self, ziel):
        if self.aktionen_nummer < 2:
            self.angriffsmalus = 5
        else:
            self.angriffsmalus = 0
        if self.ausdauer <= 0:
            WARTEN2()
            print(f"{Fore.WHITE}[Du bist erschöpft, kannst aber aus letzter Kraft noch weiterkämpfen.]{Fore.GREEN}\n")
            WARTEN2()
        self.angriff_verstaerken()  # Frage nach Angriffsverstärkung
        self.aktionen_nummer -= 1
        wuerfelwurf = self.wurf_w12()
        angriffswurf = ((wuerfelwurf + self.geschick + self.angriffsbonus + self.stufe) - self.angriffsmalus
                        - self.bewaffnung.angriffsmalus - self.malus_erschoepfung)
        angriffsmalus_gesamt = self.angriffsmalus + self.bewaffnung.angriffsmalus + self.malus_erschoepfung
        verteidigung_ziel = ziel.verteidigung - ziel.malus_erschoepfung - ziel.bewaffnung.verteidigungsmalus
        self.ausdauer -= 1 + self.panzerung.belastung + self.bewaffnung.belastung
        print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
        WARTEN2()
        print(f"{Fore.WHITE}[Angriffsbonus: {self.geschick + self.angriffsbonus + self.stufe}]{Fore.GREEN} \n")
        WARTEN2()
        if self.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Folgeaktion): -{self.angriffsmalus}]{Fore.GREEN}\n")
            WARTEN2()
        if self.bewaffnung.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Waffe): {self.bewaffnung.angriffsmalus }]\n")
        if self.ausdauer <= 0:
            self.malus_erschoepfung = 4
            print(f"{Fore.WHITE}[Angriffsmalus (Erschöpfung): -{self.malus_erschoepfung}]{Fore.GREEN}\n")
            WARTEN2()
        else:
            self.malus_erschoepfung = 0
        print(f"{Fore.WHITE}[Angriffswurf: {angriffswurf}]{Fore.GREEN} \n")
        WARTEN2()
        if ziel.ausdauer <= 0:
            ziel.malus_erschoepfung = 4
        print(f"{Fore.WHITE}[Verteidigung ({ziel.name}): {verteidigung_ziel}] {Fore.GREEN}\n")
        WARTEN2()
        if angriffswurf >= verteidigung_ziel or wuerfelwurf == 12:  # Ab hier die Erfolgsberechnung
            self.schaden(ziel)
            return
        elif wuerfelwurf == 1:
            print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
            WARTEN2()
            print(f"{Fore.WHITE}[Dein Angriff geht kolossal daneben.]{Fore.GREEN}\n")
            WARTEN2()
            self.ausdauer -= 1
            print(f"{Fore.WHITE}[Deine Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
            WARTEN2()
            return
        elif angriffswurf < verteidigung_ziel - 2:
            print(f"{Fore.RED}[MISSERFOLG] {Fore.GREEN} \n")
            WARTEN2()
            print(f"{Fore.WHITE}[Dein Angriff verfehlt {ziel.name}.]{Fore.GREEN}\n")
            WARTEN2()
            return
        else:
            ziel.ausdauer -= 1
            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
            WARTEN2()
            print(f"{Fore.WHITE}[Dein Angriff verfehlt {ziel.name} nur knapp.]{Fore.GREEN}\n")
            WARTEN2()
            return



    def angriff_verstaerken(self):
        while True:
            befehl1 = input("Willst du deinen Angriff mit mehr Krafteinsatz verstärken? "
                            "(Optionen: Ja, Nein)\n > ").lower()
            if "ja" in befehl1:
                WARTEN2()
                while True:
                    befehl2 = input(f"Wie viel Ausdauer willst du einsetzen ({self.ausdauer} verfügbar)? "
                                    f"Bitte nur ganze Zahlen eingeben.\n > ").lower()
                    try:
                        befehl2 = int(befehl2)
                        if int(befehl2) < 0:
                            WARTEN2()
                            raise ValueError
                        if int(befehl2) > self.ausdauer:
                            WARTEN2()
                            print(f"{Fore.WHITE}[So viel Ausdauer hast du derzeit leider nicht zur Verfügung. "
                                  f"Versuch's bitte noch einmal.]{Fore.GREEN}\n")
                            WARTEN2()
                            continue
                    except ValueError:
                        print(f"{Fore.WHITE}[Netter Versuch! Aber so kriegst du deine Ausdauer nicht zurück! "
                              f"Versuch's bitte noch einmal.]{Fore.GREEN}\n")
                        WARTEN2()
                        continue
                    except TypeError:
                        print("[Das ist keine Zahl. Versuch's bitte noch einmal.]\n")
                        WARTEN2()
                        continue
                    else:
                        WARTEN2()
                        self.schadensbonus += int(befehl2)
                        self.ausdauer -= int(befehl2)
                        print(f"{Fore.WHITE}[Schadensbonus (Ausdauer): {befehl2}]{Fore.GREEN}\n")
                        WARTEN2()
                        print(f"{Fore.WHITE}[Schadensbonus (gesamt): {self.schadensbonus}]{Fore.GREEN}\n")
                        WARTEN2()
                        return
            elif "nein" in befehl1:
                WARTEN2()
                return
            else:
                HOPPLA()
                WARTEN2()

class Gegner(Charakter):
    def __init__(self, name, kraft, geschick, koerperbau, grips, empathie, magie, stufe, klasse, max_ausdauer,
                 ausdauer, zauberkraft, verteidigung, willen, reflexe_bonus, reflexe, widerstand,
                 max_lebenskraft, lebenskraft, initiative_bonus, aktionen_nummer, angriffsbonus, schadensbonus,
                 max_ruestung, ruestung, edelsteine, augen, fertigkeit_sportlichkeit, fertigkeit_ueberreden,
                 fertigkeit_religion, bewaffnung, initiative, panzerung, malus_erschoepfung, schutz):
        super().__init__(name=name, kraft=kraft, geschick=geschick, koerperbau=koerperbau, grips=grips,
                         empathie=empathie, magie=magie, stufe=stufe, klasse=klasse, max_ausdauer=max_ausdauer,
                         ausdauer=ausdauer, zauberkraft=zauberkraft, verteidigung=verteidigung, willen=willen,
                         reflexe_bonus=reflexe_bonus, reflexe=reflexe, widerstand=widerstand,
                         max_lebenskraft=max_lebenskraft, lebenskraft=lebenskraft, initiative_bonus=initiative_bonus,
                         aktionen_nummer=aktionen_nummer, angriffsbonus=angriffsbonus, schadensbonus=schadensbonus,
                         max_ruestung=max_ruestung, ruestung=ruestung, edelsteine=edelsteine, augen=augen,
                         fertigkeit_sportlichkeit=fertigkeit_sportlichkeit, fertigkeit_ueberreden=fertigkeit_ueberreden,
                         fertigkeit_religion=fertigkeit_religion, bewaffnung=bewaffnung, initiative=initiative,
                         panzerung=panzerung, malus_erschoepfung=malus_erschoepfung, schutz=schutz)

    def handeln(self, ziel):
        print(f"{Fore.WHITE}[Der Ork ist dran.] {Fore.GREEN}\n")
        WARTEN2()
        while self.aktionen_nummer > 0:
            while True:
                print(f"{Fore.WHITE}[Verbleibende Aktionen: {self.aktionen_nummer}]{Fore.GREEN}\n")
                WARTEN2()
                if ziel.lebenskraft <= 0:
                    befehl = 14  # Willkürliche Zahl, die den Zug beendet.
                else:
                    befehl = random.randint(1, 20)
                if self.ausdauer < 0:
                    befehl = random.randint(1, 6)
                    if befehl in range(1, 5):
                        befehl = 14                         # willkürliche Zahl, aber sie fällt in den Erholungsbereich.
                if befehl in range (1,16):
                    WARTEN2()
                    print(f"{Fore.WHITE}[Der Ork greift an.]{Fore.GREEN}\n")
                    WARTEN2()
                    self.angreifen()
                    while self.aktionen_nummer > 0:
                        break
                    else:
                        print(f"{Fore.WHITE}[Der Ork beendet seinen Zug.]{Fore.GREEN}\n")
                        WARTEN2()
                        return
                elif befehl in range(11, 15):
                    if self.aktionen_nummer >= 2:
                        self.aktionen_nummer = 0
                        self.verteidigung += 2
                        self.ausdauer -= 1
                        WARTEN2()
                        print(f"{Fore.WHITE}[Der Gegner versucht, dir auszuweichen.]{Fore.GREEN}\n")
                        WARTEN2()
                        return
                    else:
                        continue
                elif befehl in range(1,20):
                    if self.ausdauer >= int(self.max_ausdauer/2):
                        continue
                    else:
                        WARTEN2()
                        print(f"{Fore.WHITE}[Der Ork setzt seinen Zug aus, um sich zu erholen.]{Fore.GREEN}\n")
                        WARTEN2()
                        if self.aktionen_nummer == 2:
                            if self.ausdauer < self.max_ausdauer:
                                self.ausdauer += 1
                        self.aktionen_nummer = 0
                        return
                else:
                    continue
        else:
            print(f"{Fore.WHITE}[Der Ork beendet seinen Zug.]{Fore.GREEN}\n")
            WARTEN2()
            return


    def angreifen(self):
        ziel = olig
        while self.aktionen_nummer > 0:
            befehl = random.randint(1, 3)
            if self.aktionen_nummer >= 2:
                if befehl == 1:
                    self.angriff(ziel)
                    continue
                elif befehl == 2:
                    print(f"{Fore.WHITE}[Er geht aggressiv vor.]{Fore.GREEN}\n")
                    self.angriff_aggressiv()
                    self.angriff(ziel)
                    continue
                else:
                    print(f"{Fore.WHITE}[Er achtet auf seine Verteidigung.]{Fore.GREEN}\n")
                    self.angriff_vorsichtig()
                    self.angriff(ziel)
                    continue
            else:
                self.angriff(ziel)
                WARTEN2()
        else:
            return

    def angriff(self, ziel):
        ziel = olig
        if self.aktionen_nummer < 2:
            self.angriffsmalus = 5
        else:
            self.angriffsmalus = 0
        if self.ausdauer <= 0:
            WARTEN2()
            print(f"{Fore.WHITE}[Der Ork ist erschöpft, kann aber aber noch weiterkämpfen.]{Fore.GREEN}\n")
            WARTEN2()
        while True:
            befehl1 = random.randint(1, 2)
            if self.ausdauer <= 0:
                befehl = 2
            if befehl1 == 1:
                WARTEN2()
                if self.ausdauer >= 0:
                    befehl2 = random.randint(1, 6)  # Damit die gesamte Ausdauer in einem Schlag eingesetzt wird.
                    WARTEN2()
                    self.schadensbonus += int(befehl2)
                    self.ausdauer -= int(befehl2)
                    print(f"{Fore.WHITE}[Der Gegner holt aus, um kräftiger zuzuschlagen.]{Fore.GREEN}\n")
                else:
                    WARTEN2()
            else:
                WARTEN2()
            self.aktionen_nummer -= 1
            wuerfelwurf = self.wurf_w12()
            angriffswurf = ((wuerfelwurf + self.geschick + self.angriffsbonus + self.stufe) - self.angriffsmalus
                            - self.bewaffnung.angriffsmalus - self.malus_erschoepfung)
            angriffsmalus_gesamt = self.angriffsmalus + self.bewaffnung.angriffsmalus + self.malus_erschoepfung
            verteidigung_ziel = ziel.verteidigung - ziel.malus_erschoepfung - ziel.bewaffnung.verteidigungsmalus
            self.ausdauer -= 1 + self.panzerung.belastung + self.bewaffnung.belastung
            if self.angriffsmalus > 0:
                print(f"{Fore.WHITE}[Angriffsmalus (Folgeaktion): -{self.angriffsmalus}]{Fore.GREEN}\n")
                WARTEN2()
            if self.bewaffnung.angriffsmalus > 0:
                print(f"{Fore.WHITE}[Angriffsmalus (Waffe): {self.bewaffnung.angriffsmalus}]\n")
            if self.ausdauer <= 0:
                self.malus_erschoepfung = 4
                print(f"{Fore.WHITE}[Angriffsmalus (Erschöpfung): -{self.malus_erschoepfung}]{Fore.GREEN}\n")
                WARTEN2()
            else:
                self.malus_erschoepfung = 0
            print(f"{Fore.WHITE}[Angriffswurf: {angriffswurf}]{Fore.GREEN} \n")
            WARTEN2()
            if ziel.ausdauer <= 0:
                ziel.malus_erschoepfung = 4
            print(f"{Fore.WHITE}[Verteidigung ({ziel.name}): {verteidigung_ziel}] {Fore.GREEN}\n")
            WARTEN2()
            if angriffswurf >= verteidigung_ziel or wuerfelwurf == 12:                   # Ab hier die Erfolgsberechnung
                self.schaden(ziel)
                return
            elif wuerfelwurf == 1:
                print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG.]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Der Ork schwingt kolossal daneben.]{Fore.GREEN}\n")
                WARTEN2()
                self.ausdauer -= 1
                print(f"{Fore.WHITE}[Deine Ausdauer: {ziel.ausdauer}/{ziel.max_ausdauer}]{Fore.GREEN}\n")
                WARTEN2()
                return
            elif angriffswurf < verteidigung_ziel - 2:
                print(f"{Fore.RED}[MISSERFOLG] {Fore.GREEN} \n")
                WARTEN2()
                print(f"{Fore.WHITE}[Der Angriff verfehlt {ziel.name}.]\n")
                WARTEN2()
                return
            else:
                ziel.ausdauer -= 1
                print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
                WARTEN2()
                print(f"{Fore.WHITE}[Der Angriff verfehlt {ziel.name} nur knapp.]{Fore.GREEN}\n")
                WARTEN2()
                print(f"{Fore.WHITE}[Deine Ausdauer: {ziel.ausdauer}/{ziel.max_ausdauer}]{Fore.GREEN}\n")
                WARTEN2()
                return


olig = Spieler("Olig", 5, 5, 6,5, 5, 2, 1, 0,
               12, 12, 8, 18, 6, 2, 8, 18,
               7, 7, 2, 2, 6, 0,
               0,0, False, 4, 0, 0,
            0, zweihaendige_axt, 0, False, keine_ruestung, 0,0)

ork = Gegner("Dorg", 10, 3, 10, 3, 2, 0, 1, 0,
             21, 21, 0, 16, 3, 2, 6, 13,
             11, 11, 0, 2,2, 0,
             0, 0, False, 0, 0, 0,
             0, dolch, 0, keine_ruestung, 0,0)


wessin = Gegner("Wessin", 4, 4, 6, 4,  3, 0, 1, "keine",
                 4, 4, 0, 10, 6, 2, 5, 6,
                 6, 6, 0, 0, 0, 0,
                0, 0, False, 0, 0,
                0, 0, dolch, 0, keine_ruestung, 0,0)
