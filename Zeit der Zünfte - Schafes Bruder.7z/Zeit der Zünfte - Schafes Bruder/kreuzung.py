from konstanten_und_status import *


def raum_kreuzung1():
    print(f"{Fore.WHITE}[Du betrittst die Säuselhöhle und stehst an der Kreuzung, Gesicht gen Süd.]{Fore.GREEN} \n")
    WARTEN2()
    print("Vor dir erstreckt sich ein schmaler Gang. Du spürst - und hörst - sofort den Windzug, "
          "der dir entgegen bläst. \n")
    WARTEN2()
    print("Das Pfeifen erinnert dich sofort daran, woher die Höhle ihren Namen hat. \n")
    WARTEN2()
    print("Verunsichert, vielleicht auch etwas verängstigt, gehst du trotzdem weiter. "
          "Dabei schaust du dich vorsichtig um. \n")
    WARTEN2()
    print("Die Malereien der Dorfkinder sind ordentlich verblasst, "
          "die Farbe abgetragen vom Alter und Witterungsbedingungen. \n")
    WARTEN2()
    print("Wer aber weiß, was diese Kritzeleien darstellen sollen, wird sie sofort wiedererkennen.\n")
    WARTEN2()
    print("Nur wer sie genau gemalt hat, das kannst du nicht mehr feststellen. Es ist einfach zu lange her. \n")
    WARTEN2()
    print("Ansonsten haben sich die Steinwände nicht verändert. \n")
    WARTEN2()
    print("Die Säuselhöhle ist wie immer in ihrem alten Glanz.\n")
    WARTEN2()
    print("Schon bald kommst du zu einer Weggabelung. Nein, eher einer Kreuzung. \n")
    WARTEN2()
    print("Du weißt, dass der Eingang in die Säuselhöhle im Norden liegt. \n")
    WARTEN2()
    print("Dementsprechend führt dich der gerade Weg also nach Süden. \n")
    WARTEN2()
    print("Zu deiner Linken (Osten) und Rechten (Westen) ist aber jeweils noch ein Gang. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Osten, Süden, Westen)? \n > ").lower()
        if "ost" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "nord" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_kreuzung2():
    print(f"{Fore.WHITE}[Du folgst dem Höhlengang und kommst wieder zur Kreuzung.] {Fore.GREEN}\n")
    WARTEN2()
    print("Der Gang führt dich etwa 20 Meter weiter, bevor er schließlich an dem engen Spalt endet. \n")
    WARTEN2()
    print("Zu deiner Rechten geht es nach Norden, hinter dir liegt der Osten, und vor dir der Westen. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Osten, Süden, Westen) \n > ").lower()
        if "nord" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_kreuzung3():
    print(f"{Fore.WHITE}[Du folgst dem Höhlengang und kommst wieder zur Kreuzung.]{Fore.GREEN} \n")
    WARTEN()
    print("Der Gang moosbewachsene Gang lässt sich dich schließlich wieder raus an die minimal frischere Luft.\n")
    WARTEN2()
    print("Nun stehst du wieder an der Kreuzung. \n")
    WARTEN2()
    print("Zu deiner Rechten geht es nach Süden, hinter dir liegt der Westen, und vor dir der Osten. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin (Optionen: Norden, Osten, Süden, Westen)? \n > ").lower()
        if "nord" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        elif "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_kreuzung4():
    print(f"{Fore.WHITE}[Du befindest dich wieder an der Kreuzung.]{Fore.GREEN}\n")
    WARTEN2()
    print("Du machst den ganzen scheinbar unendlichen Weg zurück und kommst schließlich wieder zur "
          "Kreuzung.\n")
    WARTEN2()
    print("Zu deiner Rechten geht es nach Osten, hinter dir liegt der Süden, und vor dir der Norden. "
          "Links geht nach Westen.\n")
    WARTEN2()
    befehl = input("Wo willst du hin? (Optionen: Norden, Osten, Süden, Westen) \n > ").lower()
    if "nord" in befehl:
        return befehl
    elif "west" in befehl:
        return befehl
    elif "süd" in befehl:
        return befehl
    elif "ost" in befehl:
        return befehl
    else:
        HOPPLA()
