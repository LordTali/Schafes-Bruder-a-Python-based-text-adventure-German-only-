from konstanten_und_status import *
from start import *
from kreuzung import *
from westkorridor import *
from suedkorridor import *
from ostkorridor import *
from kampfschleife import begegnung
from boss import *
from ende import *



def einleitung():
    raum_start1()   # Der Spieler wird durch den Anfang geleitet.
    raum_start2()
    raum_start2_1()
    raum_start3()
    return


def kreuzung():
    if not status.OST and not status.WEST and not status.SUED:  # Das Spiel schaut, aus welcher Richtung man kommt.
        frage = raum_kreuzung1()
    elif status.OST:  # Der Charakter geht nach Ost.
        status.WEST = False
        status.SUED = False
        frage = raum_kreuzung2()
    elif status.WEST:  # Der Charakter geht nach West.
        status.OST = False
        status.SUED = False
        frage = raum_kreuzung3()
    else:           # Der Charakter geht nach Süd.
        status.WEST = False
        status.OST = False
        frage = raum_kreuzung4()
    return frage


def nordgang():
    status.WEST = False
    status.OST = False
    status.SUED = False
    frage = raum_eingang_hoehle2()  # Hier geht es raus.
    return frage


def abenteuer_west():
    status.WEST = True
    while not status.ENDE:  # Der Charakter ist im Westkorridor - weiter gen Nord/Süd/Ost.
        if status.WEST_NORD_OST:
            status.WEST_NORD_OST = False
            frage = raum_westkorridor1_nord_zurueck()   # Der Charakter geht zurück zum Korridor-Anfang.
        elif status.WEST_SPRUNG:            # Wenn der Charakter gesprungen und gut gelandet ist,
            pass                            # Landet er im gleichen Raum, als wäre er gleich gen Süd gegangen.
        else:
            frage = raum_westkorridor1()
        if status.WEST_SUED_NORD:  # Der Charakter kam von Süd und wollte nach Nord.
            frage = "nord"
            status.WEST_SUED_NORD = False
        if status.WEST_SUED_SUED or status.WEST_SPRUNG:  # Der Charakter kam von Süd und wollte nach Nord.
            frage = "süd"
            status.WEST_SUED_SUED = False
        if status.WEST_SUED_OST:
            frage = "ost"
            status.WEST_SUED_OST = False
        if "nord" in frage:
            while not status.ENDE:
                if status.WEST_NORD_SUED:
                    status.WEST_NORD_SUED = False
                    frage = raum_westkorridor1_nord_von_sued()
                if status.WEST_NORD_WEST:
                    frage = raum_westkorridor1_nord2()
                else:
                    frage = raum_westkorridor1_nord()
                if "nord" in frage:
                    status.WEST_NORD_OST = True
                    break
                elif "süd" in frage:
                    frage = raum_westkorridor1_nord3()
                    if "gehe" in frage:
                        status.WEST_NORD_SUED = True
                        continue
                    elif "spr" in frage:
                        status.WEST_SPRUNG = True
                        break
                    elif "tot" in frage:            # Der Charakter stirbt. Für Detail siehe entsprechenden Raum.
                        status.TOT = True
                        status.ENDE = True
                        break
                    else:
                        status.ENDE = True
                        status.WEST_SPRUNG = True
                        break
                elif "ost" in frage:
                    frage = raum_schmugglerhoehle()  # enthält Funktion mit Edelstein-Frage.
                    if "gehe" in frage or "weg" in frage:
                        status.WEST_NORD_WEST = True
                        continue
                    else:
                        status.BOOM = True      # Der Charakter löst eine Explosion aus.
                        frage = raum_flucht1()  # Der Charakter versucht zu fliehen.
                        if frage:
                            status.KAMPF = True   # Der Charakter ist der Explosion entkommen, es kommt zum BossKampf.
                            szene_bosskampf()
                            ork.bewaffnung = kurzschwert  # Besser bewaffnet, weil Extrazeit
                            begegnung.teilnehmer_hinzufuegen(olig)
                            begegnung.teilnehmer_hinzufuegen(ork)
                            begegnung.gegner_hinzufuegen(ork)
                            begegnung.initiative_wuerfeln()
                            begegnung.reihenfolge_bestimmen()
                            begegnung.reihenfolge_anzeigen()
                            begegnung.kampf_beginnen()              # Der Rundenzähler händelt den Ablauf.
                                                                    # Danach kommt Sieg oder Niederlage.
                            while len(begegnung.teilnehmer) > 1:
                                begegnung.runden_zaehler()
                                for kaempfer in begegnung.teilnehmer:
                                    if kaempfer == olig:
                                        ziel = ork
                                    else:
                                        ziel = olig
                                    if kaempfer.lebenskraft <= 0:
                                        begegnung.teilnehmer.remove(kaempfer)
                                        continue
                                    kaempfer.handeln(ziel)
                            else:                               # Auswertung, wer gewonnen hat.
                                if olig.lebenskraft > 0:
                                    szene2_bosskampf()
                                    frage = szene_sieg()
                                    if frage:
                                        status.EPILOG = True
                                    else:
                                        status.TOT = True
                                    status.ENDE = True
                                    break
                                else:
                                    status.TOT = True
                                    status.ENDE = True
                                    szene_niederlage()
                                    break
                        else:
                            status.ENDE = True
                            status.TOT = True
                            break
        elif "süd" in frage:            # Südlicher Teil des Westkorridors. Zugang über Sprung oder Gang gen Süd.
            if status.WEST_SPRUNG:
                pass
            else:
                raum_westkorridor1_sued()
            while not status.ENDE:
                raum_westkorridor2_1()
                frage = raum_westkorridor2_2()
                if "ost" in frage:      # Hier geht es zum Bosskampf.
                    while not status.KAMPF:
                        frage = raum_westkorridor3()
                        if frage == True:  # Hier mit Absicht so kodiert wegen des Wurf-Codes.
                            status.EPILOG = True
                            status.ENDE = True
                            break
                        elif "rede" in frage:   # Überredungsversuch.
                            frage = szene_dialog1()
                            if frage:
                                szene_sieg()
                                status.ENDE = True
                                status.EPILOG = True
                                break
                            else:
                                status.KAMPF = True
                                continue
                        elif "greife" in frage:     # Versuchter Überraschungsangriff
                            status.KAMPF = True
                            continue
                        else:
                            if ork.lebenskraft > 0:     # Der Ork hat den Überraschungangriff überlebt.
                                status.KAMPF = True
                                continue
                            else:                       # Der Überraschungsangriff hat den Ork getötet.
                                status.EPILOG = True
                                status.ENDE = True
                                break
                    else:                           # Es kommt zum Kampf im Westkorridor.
                        olig.westgang = True
                        szene_bosskampf()
                        begegnung.teilnehmer_hinzufuegen(olig)
                        begegnung.teilnehmer_hinzufuegen(ork)
                        begegnung.gegner_hinzufuegen(ork)
                        begegnung.initiative_wuerfeln()
                        begegnung.reihenfolge_bestimmen()
                        begegnung.reihenfolge_anzeigen()
                        begegnung.kampf_beginnen()  # Der Rundenzähler händelt den Ablauf.
                                                    # Danach kommt Sieg oder Niederlage.
                        while len(begegnung.teilnehmer) > 1:
                            begegnung.runden_zaehler()
                            for kaempfer in begegnung.teilnehmer:
                                if kaempfer == olig:
                                    ziel = ork
                                else:
                                    ziel = olig
                                if kaempfer.lebenskraft <= 0:
                                    begegnung.teilnehmer.remove(kaempfer)
                                    continue
                                kaempfer.handeln(ziel)
                        else:                               # Auswertung, wer gewonnen hat.
                            if olig.lebenskraft > 0:
                                szene2_bosskampf()
                                frage = szene_sieg()
                                if frage:
                                    status.EPILOG = True
                                else:
                                    status.TOT = True
                                status.ENDE = True
                                break
                            else:
                                status.TOT = True
                                status.ENDE = True
                                szene_niederlage()
                                break
                else:
                    if status.WEST_SPRUNG:
                        status.WEST_SPRUNG = False
                        frage = raum_westkorridor1_sued_nach_nord()  # Der Charakter ging erst gen Nord.
                    else:
                        frage = raum_westkorridor1_sued_zurueck()
                    if "nord" in frage:
                        status.WEST_SUED_NORD = True
                        break
                    elif "süd" in frage:
                        status.WEST_SUED_SUED = True
                        break
                    else:
                        status.WEST_SUED_OST = True
                        break
            else:
                break
        else:
            break
    else:
        return


def abenteuer_sued():
    while not status.ENDE:
        status.SUED = True
        frage = raum_suedkorridor1()    # Der Charakter ist im Südkorridor. Hier nicht enthalten: Frage nach Rüstung.
        if "gehe" in frage:
            return
        else:
            frage = raum_suedkorridor1_wurf()           # Über ein großes Loch springen?
            if frage == True:
                while not status.KAMPF:
                    frage = raum_suedkorridor2()
                    if "rede" in frage:
                        frage = szene_dialog1()      # Aufeinandertreffen mit dem Gegner über Südkorridor.
                        if frage:                    # Der Überredungsversuch war erfolgreich.
                            szene_sieg()
                            status.ENDE = True
                            status.EPILOG = True
                            break
                        else:                        # Der Überredungsversuch ist gescheitert. Es kommt zum Kampf.
                            status.KAMPF = True
                            continue
                    else:                           # Es kommt zum Kampf ohne Überredungsversuch.
                        status.KAMPF = True
                        continue
                else:                               # Der Kampf beginnt.
                    szene_bosskampf()
                    begegnung.teilnehmer_hinzufuegen(olig)
                    begegnung.teilnehmer_hinzufuegen(ork)
                    begegnung.gegner_hinzufuegen(ork)
                    begegnung.initiative_wuerfeln()
                    begegnung.reihenfolge_bestimmen()
                    begegnung.reihenfolge_anzeigen()
                    begegnung.kampf_beginnen()  # Der Rundenzähler händelt den Ablauf.
                                                # Danach kommt Sieg oder Niederlage.
                    while len(begegnung.teilnehmer) > 1:
                        begegnung.runden_zaehler()
                        for kaempfer in begegnung.teilnehmer:
                            if kaempfer == olig:
                                ziel = ork
                            else:
                                ziel = olig
                            if kaempfer.lebenskraft <= 0:
                                begegnung.teilnehmer.remove(kaempfer)
                                continue
                            kaempfer.handeln(ziel)
                    else:                                       # Auswertung, wer gewonnen hat.
                        if olig.lebenskraft > 0:
                            szene2_bosskampf()
                            frage = szene_sieg()
                            if frage:
                                status.EPILOG = True
                            else:
                                status.TOT = True
                            status.ENDE = True
                            break
                        else:
                            status.TOT = True
                            status.ENDE = True
                            szene_niederlage()
                            break
            else:
                status.TOT = True
                status.ENDE = True
                break
    else:
        return


def abenteuer_ost():
    status.OST = True
    if not status.OST_WEG:
        while not status.OST_WEG:  # Der charakter ist in Ostkorridor 1 - weiter gen Nord/Ost/West
            if status.OST1_ZURUECK:
                frage = raum_ostkorridor1_zurueck() # Der Charakter kommt zu Raum 1 im Ostkorridor zurück.
            else:
                frage = raum_ostkorridor1()         # Raum 1 des Ostkorridors
            if "nord" in frage:
                while not status.ENDE:
                    frage = raum_aufgang_vorfall1_von_sued()    # Erster Aufgang zum Ort des Vorfalls
                    if "süd" in frage:                      # Zurück zu Ostkorridor 1
                        status.OST1_ZURUECK = True    # Damit ostkorridor1_zurueck geladen wird.
                        break
                    else:
                        while not status.OST_WEG:
                            frage = raum_aufgang_vorfall2_von_nord()
                            if "süd" in frage:
                                raum_ostkorridor1_von_nord()  # Zurück zu Ostkorridor 1 und raus
                                status.OST_WEG = True
                                break
                            elif "west" in frage:
                                break                         # Zurück zum Raum davor
            elif "ost" in frage:
                frage = raum_ostkorridor2()                 # Der charakter ist in Ostkorridor 2 - weiter gen Nord/West
            elif "west" in frage:                             # Zurück zur Kreuzung.
                break
            while not status.OST_WEG:
                #frage = raum_ostkorridor2()
                if "nord" in frage:
                    while not status.OST_WEG:                 # Aufgang 2 zum Vorfall
                        frage = raum_aufgang_vorfall2_von_sued()
                        if "ost" in frage:
                            while not status.ENDE:
                                frage = raum_ostkorridor2()
                                if "nord" in frage:
                                    break                     # Zurück zum Raum davor.
                                elif "west" in frage:
                                    raum_ostkorridor1_von_nord()
                                    status.OST_WEG = True     # Zurück zu Ostkorridor 1 und raus.
                                    break
                        else:                                 # Zurück zu Ostkorridor 1 und raus
                            raum_aufgang_vorfall1_von_nord()
                            status.OST_WEG = True
                            break
                    else:
                        break
                elif "west" in frage:                         # Zurück zur Ostkorridor 1.
                    break
            else:
                break
        else:
            return
    else:                                                      # Es geht nur einmal nach Osten. Keine Wiederkehr.
        print("Du schaust noch einmal über die Schulter, fragst dich aber, warum.\n")
        WARTEN2()
        print("Doch, eigentlich weißt du das - du willst es dir nur nicht eingestehen.\n")
        WARTEN2()
        print("Maika.\n")
        WARTEN2()
        print("Nach all diesen Jahren ist es immer noch nicht klar, wessen Schuld das war.\n")
        WARTEN2()
        print("Anschuldigungen bringen inzwischen nichts mehr, aber vermutlich "
              "hatte jeder seinen Teil beigetragen.\n")
        WARTEN2()
        print("Letztlich beschließt du, die Angelegenheit zu verdrängen. "
              "Darin bist du mittlerweile geübt.\n")
        WARTEN2()
        return
