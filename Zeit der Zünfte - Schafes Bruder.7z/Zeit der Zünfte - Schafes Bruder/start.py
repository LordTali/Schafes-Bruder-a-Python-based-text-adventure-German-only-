import random
import time
from colorama import *
from konstanten_und_status import *
from charaktere import *


def raum_start1():
    WARTEN()
    print(f"{Fore.GREEN}Willkommen bei ZEIT DER ZÜNFTE: SCHAFES BRUDER! \n \n")
    WARTEN3()
    print("Dies ist das erste Mini-Abenteuer im Zeit-Der-Zünfte-System von Vitali Hänisch. \n")
    WARTEN2()
    print("Es ist ein kurzes Textabenteuer, das mit Python 3 erstellt wurde. \n")
    WARTEN2()
    print("Hier sind die Regeln: An vielen Stellen der Geschichte wirst du aufgerufen, eine Antwort einzugeben. \n")
    WARTEN2()
    print("Bitte tu dies nach den Regeln der deutschen Sprache. \n")
    WARTEN2()
    print("Die möglichen Antworten sind dir in diesem Abenteuer meistens vorgegeben, bitte wähle eine davon aus.\n")
    WARTEN2()
    print("In der Ausgestaltung hast du allerdings freie Hand.\n")
    WARTEN2()
    print("Wenn die Aufforderung etwa \"willst du gehen oder bleiben?\" lautet, fühl dich frei, mit der konkreten "
          "Formulierung zu experimentieren.\n"
          "Bedenke allerdings, dass das Spiel auf bestimmte Schlüsselwörter achtet.\n")
    WARTEN2()
    print("Zum guten Ton würde aber zum Beispiel eine Antwort wie \"ich gehe.\" bzw. \"ich bleibe.\" ohne die "
          "Anführungszeichen gehören.\n")
    return


def raum_start2():
    while True:
        befehl = input("Testen wir das doch gleich mal aus! Gib \"Spiel starten\" ein, um fortzufahren. \n >").lower()
        if "start" in befehl or "spiel" in befehl:
            WARTEN()
            print("\nPrima! Dann legen wir los. \n")
            WARTEN2()
            return
        else:
            HOPPLA()


def raum_start2_1():
    while True:
        befehl = input("Willst du ein paar Tipps zu diesem Spiel erfahren? (Optionen: ja, nein)\n > ").lower()
        if "ja" in befehl:
            WARTEN3()
            print(f"In dieser Geschichte spielst du als {Fore.YELLOW}Olig Schäferstund{Fore.GREEN}, "
                  f"ein Bauer aus einem kleinen nicht näher bestimmten Dorf irgendwo im Nordland-Imperium der "
                  f"Spielwelt, Yarus.\n")
            WARTEN2()
            print("Die Geschichte entwickelt sich abhängig von deinen Antworten.\n")
            WARTEN2()
            print("Manche Ereignisse werden aber – wie in fast jedem Rollenspielsystem, und diesem Abenteuer liegt "
                  "eines zugrunde – mit einem Würfelwurf entschieden. \n")
            WARTEN2()
            print("Überlege also gut, was du tust. \n")
            WARTEN2()
            print("Aber wo wir gerade dabei sind: Mach das Programmfenster ein bisschen breiter, "
                  "um den Text ordentlich lesen zu können.\n")
            WARTEN2()
            print("Und ansonsten... Mach's dir bequem, hol dir was zu trinken,\nmach am besten irgendeine "
                  "\"dungeon-taugliche\" Musik deiner Wahl an, und genieße das Amateur-Theater.\n")
            WARTEN2()
            print("Ein letzter Tipp: Du wirst hier ein bisschen rumlaufen müssen.\n")
            WARTEN2()
            print("Falls Raumorientierung also nicht so deine Stärke ist, wäre es vielleicht eine gute Idee, "
                  "Stift und Papier zur Hand zu nehmen, um eine Art Karte zu zeichnen.\n")
            WARTEN2()
            print("Und damit geht unser imaginärer Vorhang auf...\n \n")
            WARTEN2()
            return
        elif "nein" in befehl:
            WARTEN3()
            print("Dann geht unser imaginärer Vorhang jetzt auf...\n")
            WARTEN3()
            return
        else:
            HOPPLA()


def raum_start3():
    while True:
        befehl = input("Gib nun \"weiter\" ein, um das Abenteuer zu beginnen.\n > ").lower()
        if befehl == "weiter":
            WARTEN2()
            return
        else:
            HOPPLA()


def raum_start4():
    print("\n \nDu spürst, wie deine Beine langsam müde werden. \n")
    WARTEN2()
    print("Seit Sonnenaufgang bist du schon unterwegs, auf der Suche nach deinem Schaf, Dolly. \n")
    WARTEN2()
    print("Du kannst dir nicht erklären, wer sie gestohlen hat. \n")
    WARTEN2()
    print("Oder warum. \n")
    WARTEN2()
    print("Dass man sie gestohlen hat, steht jedoch außer Frage. \n")
    WARTEN2()
    print("Du hast den Stall gut abgeschlossen und gesichert, alleine wäre sie nicht ausgebrochen. \n")
    WARTEN3()
    print("Als einfacher Bauer kannst du dir auch kein neues Schaf leisten. \n")
    WARTEN2()
    print("Der Winter naht, du brauchst die Wolle. \n")
    WARTEN2()
    print("Dabei bist du dir noch nicht sicher, wofür genau. \n")
    WARTEN2()
    print("Etwas Neues zum Überziehen wäre sicherlich praktisch.\n")
    WARTEN2()
    print("Aber du kennst auch genug Leute, die dafür eine ganze Handvoll Ran ausgeben würden. \n")
    WARTEN2()
    print("Vielleicht sogar einen ganzen Bur! \n")
    WARTEN2()
    print("Das ist eine Menge Geld. Vielleicht würde die Wolle aber auch für Beides reichen, du hast ja nicht "
          "umsonst das fluffigste Schaf im ganzen Dorf. \n")
    WARTEN2()
    print("Vielleicht sogar im ganzen Imperium, wenn man dich fragt.\n")
    WARTEN3()
    print("Bis jetzt fehlt von Dolly aber jede Spur. \n")
    WARTEN2()
    print("Langsam fragst du dich, ob du sie überhaupt noch finden kannst. \n")
    WARTEN3()
    return


def raum_start5():
    while True:
        befehl = input("Willst du noch einen letzten Versuch wagen? (ja, nein)\n > ").lower()
        if "nein" in befehl:
            print("Tja… Die Suche ist wohl zwecklos. \n")
            WARTEN2()
            print("Du glaubst nicht, dass du Dolly noch finden wirst. \n")
            WARTEN2()
            print("Außerdem hast du noch andere Tiere, die versorgt werden müssen. \n")
            WARTEN2()
            print("So traurig das auch ist – Dolly ist weg. \n")
            WARTEN2()
            print("Ein weiterer unglücklicher Tag im Leben eines Bauern. \n")
            WARTEN2()
            print("Aber gut, das Leben geht weiter, und den Winter kriegt man schon irgendwie überstanden, "
                  "nicht wahr? \n  \n")
            WARTEN2()
            print("Ende \n")
            WARTEN2()
            return False
        elif "ja" in befehl:
            print("Einen letzten Versuch willst du noch wagen. \n")
            WARTEN2()
            print("Du strengst dich an und lässt einen genauen Blick über das Feld schweifen. \n")
            WARTEN2()
            print("Zum Glück ist es nicht das erste Mal, dass du ein Tier suchst. \n")
            WARTEN2()
            print("Dein Blick ist für solche Dinge eigentlich gut trainiert. \n")
            WARTEN3()
            print(f"{Fore.WHITE}[Willkommen bei deinem ersten Fertigkeitswurf des Spiels.]\n")
            WARTEN2()
            print(f"[Dieser Wurf testet deine Wahrnehmung. Kannst du irgendwelche Spuren erkennen, "
                  f"um dein Schaf zu finden?]\n")
            WARTEN2()
            print(f"[Fertigkeitswürfe werden mit einem 12-seitigen Würfel (W12) abgelegt. "
                  f"Dein Charakter hat einen Bonus, um etwas mit den Augen zu erkennen. Bei einem Wurf wird dieser "
                  f"auf das Ergebnis angerechnet.]{Fore.GREEN} \n ")
            WARTEN2()
            while True:
                befehl = input("Gib nun \"würfeln\" ein, um den Wurf abzulegen. \n > ")
                if "würfeln" in befehl:
                    wurf = olig.wurf_erkennen(10)
                    WARTEN2()
                    if not wurf:
                        print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
                        WARTEN2()
                        print("Tja… Die Suche ist wohl zwecklos. \n")
                        WARTEN2()
                        print("Du glaubst nicht, dass du Dolly noch finden wirst. \n")
                        WARTEN2()
                        print("Außerdem hast du noch andere Tiere, die versorgt werden müssen. \n")
                        WARTEN2()
                        print("So traurig das auch ist – Dolly ist weg. \n")
                        WARTEN2()
                        print("Ein weiterer unglücklicher Tag im Leben eines Bauern. \n")
                        WARTEN2()
                        print("Aber gut, das Leben geht weiter, und den Winter kriegt man schon irgendwie überstanden, "
                              "nicht wahr?\n")
                        WARTEN2()
                        print("Ende \n")
                        WARTEN2()
                        return False
                    else:
                        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN} \n")
                        WARTEN2()
                        print("Und als es schien, es gebe keine Hoffnung mehr, entdeckst du etwas: Spuren! \n")
                        WARTEN()
                        print("Natürlich sind Spuren auf einem Waldweg nichts Besonderes, aber so große Spuren können "
                              "eigentlich nur Orks oder Sim’iari hinterlassen, und Letztere lassen sich hier nicht "
                              "blicken. \n")
                        WARTEN2()
                        print("Und das aus gutem Grund.\n")
                        WARTEN2()
                        print("In der Stadt mögen sie inzwischen anerkannte Untertanen des Imperiums sein. \n")
                        WARTEN2()
                        print("Hier auf dem Land haben die Leute aber noch nicht vergessen, was sie hier vor noch "
                              "gar nicht so langer Zeit getan haben. \n")
                        WARTEN2()
                        print("Aber gut, sich darüber zu beklagen bringt nichts. \n")
                        WARTEN2()
                        print("Dann musst du dem mutmaßlichen Entführer eben folgen und Dolly zurückholen. \n")
                        WARTEN2()
                        print("Die Spuren führen zu einer großen Höhle.\n")
                        WARTEN2()
                        print(f"Die \"{Fore.YELLOW}Säuselhöhle{Fore.GREEN}\", wie man sie nennt.\n")
                        WARTEN2()
                        print("Eigentlich kennst du sie gut, früher war sie ein beliebter Spielort für Kinder. \n")
                        WARTEN2()
                        print("Dann kam der Vorfall mit Maika und… Naja, egal, unangenehme Erinnerungen kannst du "
                              "gerade nicht gebrauchen. \n")
                        WARTEN2()
                        print("Fakt ist aber: Du warst lange nicht mehr da.\n")
                        WARTEN2()
                        print("Vieles hat sich verändert, und vielleicht täuscht dich auch dein Gedächtnis. \n")
                        WARTEN2()
                        print("Bist du überhaupt dafür ausgerüstet, hineinzugehen? Ein Seil, eine Axt und eine Fackel "
                              "samt Zeug zum Anzünden in einem kleinen Beutelchen, "
                              "mehr hast du momentan nicht am Leib. \n")
                        WARTEN2()
                        print("Vielleicht solltest du erst deine Rüstung anlegen und dich besser vorbereiten, "
                              "und dann zurückkehren? \n")
                        WARTEN2()
                        print("Dann wiederum, vielleicht ist es bis dahin zu spät! \n")
                        WARTEN2()
                        print("Wer weiß, was der Unhold mit der armen Dolly anstellen will? \n")
                        WARTEN2()
                        print("Außerdem wird es langsam dunkel. Deine Augen werden in der Höhle nicht viel erkennen.\n")
                        WARTEN2()
                        print("Deine Fackel würde das Problem beheben, aber falls du schnell sein oder kämpfen musst, "
                              "könnte es zum Problem werden. \n")
                        WARTEN2()
                        print("Oder… Moment, weißt du noch, wie dieser eine Zauber ging? \n")
                        WARTEN2()
                        print("Klar, du bist kein Zauberer, aber du hast mal diesen einen Typen von der Akademie eine "
                              "Weile mietfrei bei dir wohnen lassen, als er sein Studiengedöns durchgeführt hat.\n")
                        WARTEN2()
                        print("Aus Dankbarkeit hat er dir damals beigebracht, wie man sich eine Lichtquelle "
                              "erschafft.\n")
                        WARTEN2()
                        print("Du hast eigentlich magisches Geschick, aber so etwas Einfaches könntest du unter "
                              "Umständen gerade noch hinkriegen.\n")
                        WARTEN2()
                        print("Du könntest damit zum Beispiel deine Axt zum Leuchten bringen.\n")
                        WARTEN2()
                        print("Zumindest könntest du es versuchen, gemacht hast du ja noch nie. \n")
                        WARTEN2()
                        print("Und würde dich das nicht unter Umständen verraten, "
                              "falls du eher vorsichtig und heimlich vorgehen willst? \n")
                        WARTEN2()
                        print("Schwierig. Einen Versuch wert könnte es trotzdem sein! \n")
                        return True
                else:
                    HOPPLA()


def raum_start6():
    while True:
        befehl = input("Was willst du tun? (Optionen: weggehen, Fackel anzünden, zaubern) \n > ").lower()
        if "gehe" in befehl or "weg" in befehl:
            print("Du kehrst um und kommst am nächsten Morgen in voller Montur wieder. \n")
            WARTEN2()
            print("Mit der richtigen Ausrüstung lässt sich die Höhle ohne Probleme passieren und findest "
                  "schließlich Dolly. \n")
            WARTEN2()
            print("Was von ihr übrig ist. \n")
            WARTEN2()
            print("Von dem Ork fehlt jede Spur. \n")
            WARTEN2()
            print("Egal, was immer du später erzählst: Du wirst der Szenerie, die du gesehen hast, "
                  "niemals gerecht werden. \n")
            WARTEN2()
            print("Eigentlich willst du das Bild auch nicht realitätsnah wiedergeben. \n")
            WARTEN2()
            print("Du willst nicht einmal daran denken, was du gesehen hast. \n")
            WARTEN2()
            print("Es schien irgendeine Art Ritual gewesen zu sein, so viel kannst du noch sagen. \n")
            WARTEN2()
            print("Und der Rest… Ist Schweigen. \n")
            WARTEN2()
            print("Und was soll das auch bringen, in der Vergangenheit rumzustochern?\n")
            WARTEN2()
            print("An der Gegenwart wird das nichts ändern. \n")
            WARTEN2()
            print("Dolly ist weg. \n")
            WARTEN2()
            print("Ein weiterer unglücklicher Tag im Leben eines Bauern. \n")
            WARTEN2()
            print("Aber das Leben weiter, und den Winter… Den Winter kriegt man schon irgendwie überstanden. \n")
            WARTEN2()
            print("Ende \n")
            WARTEN2()
            return False
        elif "fackel" in befehl:
            print("Du kramst in deinem kleinen Beutelchen nach Zündzeug. "
                  "Gut, dass du zumindest dafür vorgesorgt hast! \n")
            WARTEN2()
            print("Du brauchst ein paar Versuche, dann leuchtet sich die Fackel auf. \n")
            WARTEN2()
            print("Sie spendet genug Licht, um die Höhle ordentlich zu erkunden. \n")
            WARTEN2()
            print("Wenn du jetzt noch zögerst, sie zu betreten, liegt es zumindest nicht (mehr) an der Dunkelheit. \n")
            WARTEN2()
            return True
        elif "zauber" in befehl:
            WARTEN2()
            print("Du gehst einmal in dich und sammelst deine Kräfte. \n")
            WARTEN2()
            print("Langsam, aber sicher fokussierst du deine innere Gefühlswelt und lässt dich von magischen "
                  "Strömen durchdringen. \n")
            WARTEN2()
            print("Jetzt musst du sie nur noch in etwas umwandeln, das du willst: Licht. \n")
            WARTEN2()
            print(f"{Fore.WHITE}[Nun versuchen wir es mit einem magischen Wurf.]\n")
            WARTEN2()
            print(f"[Jeder Zauber braucht einen bestimmten Kontrollwert (abgelegt mit einem W6) und den "
                  f"Einsatz von {Fore.MAGENTA}Zauberkraft{Fore.WHITE} (diese wird von deinen Werten und der "
                  f"Charakterklasse bestimmt).]\n")
            WARTEN2()
            print(f"[Eigentlich solltest du als einfacher Bauer nicht in der Lage sein, "
                  f"zu zaubern.]\n")
            WARTEN2()
            print(f"[Aber wir machen hier mal eine Ausnahme, zumal \"{Fore.MAGENTA}Licht{Fore.WHITE}\" ein "
                  f"sehr einfacher Zauber ist.{Fore.GREEN}]\n")
            WARTEN2()
            befehl = input("[Gib nun \"würfeln\" ein, um den Wurf abzulegen.] \n > ")
            while True:
                if "würfel" in befehl:
                    wuerfel_w6 = olig.wurf_w6()
                    WARTEN2()
                    print(f"\n[Dein Wurf (Kontrolle): {wuerfel_w6}]\n")
                    WARTEN2()
                    if wuerfel_w6 < 4:
                        print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
                        WARTEN2()
                        print("Leider schaffst du es nicht, diesen letzten Schritt zu machen. \n")
                        WARTEN2()
                        print("Bei der Ätherischen Magie macht Übung eben den Meister, "
                              "und du bist darin nicht einmal ein Lehrling. \n")
                        WARTEN2()
                        print("Nun gut, du hast immer noch deine Fackel. \n")
                        WARTEN2()
                        print("Du zündest sie an und betrittst die Säuselhöhle. \n")
                        WARTEN2()
                        return True
                    else:
                        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN} \n")
                        WARTEN2()
                        print("Du hast zwar noch nie gezaubert, instinktiv weißt du aber trotzdem, "
                              "was du tun musst. \n")
                        WARTEN2()
                        print("Eine Welle unbeschreiblicher Euphorie, ja gar Erregung, "
                              "überkommt dich, während deine Finger die richtigen Bewegungen machen. \n")
                        WARTEN2()
                        print("Einige Sekunden später leuchtet dein Leinenhemd auf. Eigentlich wolltest du deine "
                              "Axt zum Leuchten bringen, aber nun gut, zumindest hast du Licht. \n")
                        WARTEN2()
                        print("Du zuckst einmal mit den Schultern und betrittst die Säuselhöhle. \n")
                        WARTEN2()
                        return True
                else:
                    HOPPLA()
        else:
            HOPPLA()


def raum_eingang_hoehle2():
    print("Du gehst nach Norden und verlässt die Säuselhöhle. \n")
    WARTEN2()
    print("Vor dir erstreckt sich ein schmaler Gang. Du spürst - und hörst - sofort den Windzug, "
          "der dir entgegen bläst. \n")
    WARTEN2()
    print("Das Pfeifen erinnert dich mal wieder daran, woher die Höhle ihren Namen hat. \n")
    WARTEN2()
    print("Verunsichert gehst du trotzdem weiter und kommst raus der Höhle, die jetzt hinter dir im Süden liegt. \n")
    WARTEN2()
    print("Du fragst dich, warum du wieder rausgegangen bist. \n")
    WARTEN2()
    print("Vielleicht waren die verblassten Erinnerungen zu schmerzhaft, vielleicht bist du aber auch nicht bereit. \n")
    WARTEN2()
    print("Nicht bereit, dich der Gefahr zu stellen, oder du willst dich doch besser vorbereiten. \n")
    WARTEN2()
    print("Du kannst also umkehren oder in den Süden gehen. \n")
    WARTEN2()
    while True:
        befehl = input("Was willst du tun? (Optionen: Weggehen, Süden) \n >").lower()
        if "weg" in befehl or "gehe" in befehl:
            print("Du kehrst um und kommst am nächsten Morgen in voller Montur wieder. \n")
            WARTEN2()
            print("Mit der Ausrüstung lässt sich die Höhle ohne Probleme passieren "
                  "und du findest schließlich Dolly. \n")
            WARTEN2()
            print("Was von ihr übrig ist. \n")
            WARTEN2()
            print("Von dem Ork fehlt jede Spur. \n")
            WARTEN2()
            print("Egal, was immer du später erzählst: Du wirst der Szenerie, die du gesehen hast, "
                  "niemals gerecht werden. \n")
            WARTEN2()
            print("Eigentlich willst du das Bild auch nicht realitätsnah wiedergeben. \n")
            WARTEN2()
            print("Du willst nicht einmal daran denken, was du gesehen hast. \n")
            WARTEN2()
            print("Es schien irgendeine Art Ritual gewesen zu sein, so viel kannst du noch sagen. \n")
            WARTEN2()
            print("Und der Rest… Ist Schweigen. \n")
            WARTEN2()
            print("Und was soll das auch bringen, in der Vergangenheit rumzustochern?\n")
            WARTEN2()
            print("An der Gegenwart wird das nichts ändern. \n")
            WARTEN2()
            print("Dolly ist weg. \n")
            WARTEN2()
            print("Ein weiterer unglücklicher Tag im Leben eines Bauern. \n")
            WARTEN2()
            print("Aber das Leben geht weiter, und den Winter… Den Winter kriegt man schon irgendwie überstanden. \n")
            WARTEN2()
            print("Ende \n")
            WARTEN2()
            return False
        elif "süd" in befehl:
            WARTEN()
            return True
        else:
            HOPPLA()
