import random
import time
from colorama import *
from charaktere import *
from konstanten_und_status import *

def raum_ostkorridor1():
    print(f"\n{Fore.WHITE}[Du befindest dich im östlichen Gang.]{Fore.GREEN}\n")
    WARTEN2()
    print("Nachdem du dich durch einen kurzen, aber sehr schmalen Gang zwängst, wird dein Weg wieder breiter. \n")
    WARTEN2()
    print("Dolly hätte hier nie und nimmer durchgepasst, sodass du dich langsam fragst, was dich geritten hat, "
          "diesen Weg zu nehmen. \n")
    WARTEN2()
    print("Aber jetzt bist du nun mal hier.\n")
    WARTEN2()
    print("Vor dir erstreckt sich ein weiterer Gang, zu deiner Linken siehst du aber eine Abzweigung, gen Norden. \n")
    WARTEN2()
    print("Natürlich könntest du auch immer noch umkehren und nach Westen gehen, zurück, in den Gang, "
          "aus dem du gekommen bist. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin (Norden, Osten, Westen)? \n > ").lower()
        if "nord" in befehl:
            return befehl
        if "ost" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_ostkorridor1_zurueck():
    print("Du gehst zurück nach Süden und wieder am Spalt, durch den du in den Ostgang gekommen bist.\n")
    WARTEN2()
    print("Nachdem du dich durch einen kurzen, aber sehr schmalen Gang zwängst, wird dein Weg wieder breiter. \n")
    WARTEN2()
    print("Dolly hätte hier nie und nimmer durchgepasst, sodass du dich langsam fragst, was dich geritten hat, "
          "diesen Weg zu nehmen. \n")
    WARTEN2()
    print("Aber jetzt bist du nun mal hier. Vor dir erstreckt sich ein weiterer Gang, zu deiner Linken siehst du aber "
          "eine Abzweigung, gen Norden. \n")
    WARTEN2()
    print("Natürlich könntest du auch immer noch umkehren und nach Westen gehen, zurück, in den Gang, aus dem du "
          "gekommen bist. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin (Norden, Osten, Westen)? \n > ").lower()
        if "nord" in befehl:
            return befehl
        if "ost" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_ostkorridor2():
    print(f"{Fore.WHITE}[Du folgst dem östlichen Gang.]{Fore.GREEN} \n")
    WARTEN2()
    print("Der Gang führt dich noch etwa 20 Meter weiter, bevor er schließlich endet. \n")
    WARTEN2()
    print("An der Felswand siehst du weitere Malereien. \n")
    WARTEN2()
    print("Seltsam. Du kannst dich gar nicht daran erinnern, hier mal gespielt zu haben. \n")
    WARTEN2()
    print("Dann wiederum: Auf dem Boden liegen irgendwelche Scherben. \n")
    WARTEN2()
    print("Vermutlich war das einmal Tongeschirr, vielleicht auch Tonspielzeug. "
          "Das Dorf ist schließlich für seine Tonpuppen in der Region bekannt. \n")
    WARTEN2()
    print("Aber die dem auch immer sei, führt der Weg hier nicht mehr weiter. \n")
    WARTEN2()
    print("Zu deiner Linken ist ein weiterer Gang, etwa schmaler als dieser hier, aber zumindest breit genug, "
          "dass du dich nicht zu sehr anstrengen musst. \n")
    WARTEN2()
    print("Natürlich könntest du auch wieder umkehren – der erste Gang zu deiner Linken war immerhin etwas breiter. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Norden, Westen) \n > ").lower()
        if "nord" in befehl:
            return befehl
        if "west" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_aufgang_vorfall1_von_sued():
    print(f"{Fore.WHITE}[Du folgst der ersten Abzweigung des Ostgangs.]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Weg windet sich mehr als die anderen, aber du kommst trotzdem gut durch. \n")
    WARTEN2()
    print("Der Gang führt zu einer kleinen Lichtung. Oder so würdest du sie nennen, wenn du im Wald wärst. \n")
    WARTEN2()
    print("Wie heißen solche Öffnungen in einer Höhle? \n")
    WARTEN2()
    print("Du müsstest später jemanden fragen, jetzt fällt es dir nicht ein. \n")
    WARTEN2()
    print("Dafür weißt du jetzt wieder, wo du bist. \n")
    WARTEN2()
    print("In dieser Dämmerung würdest du ohne Licht nichts erkennen, "
          "tagsüber sollte hier aber alles einigermaßen sichtbar sein.\n")
    WARTEN2()
    print("Zumindest deutet das hohe Pfeifen über dir auf jede Menge Löcher, durch die ein bisschen Tageslicht "
          "- und Regenwasser - eindringen könnte.\n")
    WARTEN2()
    print("Die feuchte Felswand trägt immer noch Spuren von jenem Tag. \n")
    WARTEN2()
    print("Nicht einmal die Feuchtigkeit und die Zeit konnten hier alles verwischen. \n")
    WARTEN2()
    print("Oder die Spuren auf dem Boden, den schon lange niemand mehr berührte. \n")
    WARTEN2()
    print("Oh, Maika… \n")
    WARTEN2()
    print("Wenn du nur die Zeit zurückdrehen könntest. \n")
    WARTEN2()
    print("Aber es ist zu spät. \n")
    WARTEN2()
    print("Vielleicht war es ein Fehler, hierher zu kommen – zu viele Geister der Vergangenheit hier drin. \n")
    WARTEN2()
    print("Du schüttelst deinen Kopf und zwingst dich zurück in das Hier und Jetzt. \n")
    WARTEN2()
    print("Vielleicht kannst du später mit jemanden aus dem Dorf bei einem Glas Pfefferwodka darüber reden, "
          "aber jetzt musst du weiter. \n")
    WARTEN2()
    print("Du kannst natürlich wieder zurückgehen, aber zu deiner Rechten führt noch ein Gang Richtung Osten. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Süden, Osten) \n > ").lower()
        if "süd" in befehl:
            return befehl
        elif "ost" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_aufgang_vorfall2_von_sued():
    print(f"{Fore.WHITE}[Du folgst der zweiten Abzweigung des Ostgangs.]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Gang ist schmal, aber du kommst trotzdem durch. \n")
    WARTEN2()
    print("Er führt zu einer kleinen Lichtung. Oder so würdest du sie nennen, wenn du im Wald wärst. \n")
    WARTEN2()
    print("Wie heißen solche Öffnungen in einer Höhle? Du müsstest später jemanden fragen, "
          "jetzt fällt es dir nicht ein. \n")
    WARTEN2()
    print("Dafür weißt du jetzt wieder, wo du bist. \n")
    WARTEN2()
    print("In dieser Dämmerung würdest du ohne Licht nichts erkennen, tagsüber sollte hier aber alles "
          "einigermaßen sichtbar sein.\n")
    WARTEN2()
    print("Zumindest deutet das hohe Pfeifen über dir auf jede Menge Löcher, durch die ein bisschen Tageslicht"
          " - und Regenwasser - eindringen könnte.\n")
    WARTEN2()
    print("Die feuchte Felswand trägt immer noch Spuren von jenem Tag. \n")
    WARTEN2()
    print("Nicht einmal die Feuchtigkeit und die Zeit konnten hier alles verwischen. \n")
    WARTEN2()
    print("Oder die Spuren auf dem Boden, den schon lange niemand mehr berührte. \n")
    WARTEN2()
    print("Oh, Maika…  Wenn du nur die Zeit zurückdrehen könntest. \n")
    WARTEN2()
    print("Aber es ist zu spät. \n")
    WARTEN2()
    print("Vielleicht war es ein Fehler, hierher zu kommen – zu viele Geister der Vergangenheit hier drin. \n")
    WARTEN2()
    print("Du schüttelst deinen Kopf und zwingst dich zurück in das Hier und Jetzt.\n")
    WARTEN2()
    print("Vielleicht kannst du später mit jemanden aus dem Dorf bei einem Glas Pfefferwodka darüber reden, "
          "aber jetzt musst du weiter. \n")
    WARTEN2()
    print("Du kannst natürlich wieder zurückgehen, aber zu deiner Linken - bzw. vor dir - "
          "führt noch ein Gang Richtung Westen und biegt nach Süden ab. \n")
    WARTEN2()
    while True:
        befehl = input("Wo willst du hin? (Optionen: Westen, Osten) \n > ").lower()
        if "ost" in befehl:
            return befehl
        elif "west" in befehl:
            return befehl
        else:
            HOPPLA()


def raum_ostkorridor1_von_nord():
    print("Der Gang ist schmal, aber du kommst trotzdem durch. \n")
    WARTEN2()
    print("Nach etwa 20 Schritten endet aber auch dieser Weg. \n")
    WARTEN2()
    print("Zu deiner Rechten geht es aber weiter, gen West. \n")
    WARTEN2()
    print("Und natürlich gäbe es noch den Weg zurück. \n")
    WARTEN2()
    print("An der Felswand siehst du weitere Malereien. \n")
    WARTEN2()
    print("Seltsam. Du kannst dich gar nicht daran erinnern, hier mal gespielt zu haben. \n")
    WARTEN2()
    print("Dann wiederum: Auf dem Boden liegen irgendwelche Scherben. \n")
    WARTEN2()
    print("Vermutlich war das einmal Tongeschirr, vielleicht auch Tonspielzeug.\n")
    WARTEN2()
    print(" Das Dorf ist schließlich für seine Tonpuppen in der Region bekannt. \n")
    WARTEN2()
    print("Aber wie dem auch immer sei, führt der Weg hier nicht mehr weiter. \n")
    WARTEN2()
    print("Zu deiner Rechten ist ein weiterer Gang nach Westen. \n")
    WARTEN2()
    print("Natürlich könntest du auch wieder umkehren, gen Norden, aber du wagst es nicht, "
          "diesen Ort noch einmal zu betreten. \n")
    WARTEN2()
    print("Du gehst also weiter. Du kommst voran und siehst einen schmalen Spalt in der Felswand vor dir. \n")
    WARTEN2()
    print("Moment mal... Ach, verdammt! \n")
    WARTEN2()
    print("Herzlichen Glückwunsch, du bist im Kreis gegangen! \n")
    WARTEN2()
    print("Du kannst gar nicht beschreiben, wie sehr dich das gerade ärgert, so eine Zeitverschwendung! \n")
    WARTEN2()
    print("Aber es bringt nichts, du musst immer noch weiter. \n")
    WARTEN2()
    print("Zu deiner Linken geht es immer noch nach Osten, aber was ist der Sinn? \n")
    WARTEN2()
    print("Du gehst gerade aus, gen Westen, und zwängst dich wieder durch den engen Spalt. \n")
    WARTEN2()
    print("[Du verlässt den östlichen Gang und kommst wieder zur Kreuzung, Gesicht gen West.] \n")
    WARTEN2()
    print("Nun stehst du wieder an der Kreuzung. \n")
    WARTEN2()
    print("Du weißt, dass der Eingang in die Säuselhöhle im Norden liegt, von dir aus gesehen rechts. \n")
    WARTEN2()
    print("Dementsprechend führt dich der gerade Weg also nach Westen. \n")
    WARTEN2()
    print("Du deiner Linken liegt der Süden, und hinter dir geht es Richtung Ost.\n")
    WARTEN2()
    return


def raum_aufgang_vorfall1_von_nord():
    print(f"{Fore.WHITE}[Du verlässt den Ort des Vorfalls und folgst der vor dir liegenden Abzweigung nach Süden]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Gang windet sich mehr als die anderen, fühlt sich von der Länge her aber nur minimal länger an. \n")
    WARTEN2()
    print("Du kommst zu einem weiteren Gang, der nach links führt. \n")
    WARTEN2()
    print("Moment mal! \n")
    WARTEN2()
    print("Von dir aus gesehen wäre links der Osten, und an den Wänden siehst du vertraute Spuren und Malereien... \n")
    WARTEN2()
    print("Ach, verdammt! \n")
    WARTEN2()
    print("Herzlichen Glückwunsch, du bist im Kreis gegangen! \n")
    WARTEN2()
    print("Du kannst gar nicht beschreiben, wie sehr dich das gerade ärgert, so eine Zeitverschwendung! \n")
    WARTEN2()
    print("Aber es bringt nichts, du musst immer noch weiter. \n")
    WARTEN2()
    print("Zu deiner Linken geht es immer noch nach Osten, aber was ist der Sinn? \n")
    WARTEN2()
    print("Du biegst nach rechts ab, gen Westen, und zwängst dich wieder durch den engen Spalt. \n")
    WARTEN2()
    print("Nun stehst du wieder an der Kreuzung.\n")
    WARTEN2()
    print("Du weißt, dass der Eingang in die Säuselhöhle im Norden liegt, von dir aus gesehen rechts. \n")
    WARTEN2()
    print("Dementsprechend führt dich der gerade Weg also nach Westen. \n")
    WARTEN2()
    print("Du deiner Linken liegt der Süden, und hinter dir geht es Richtung Ost. \n")
    WARTEN2()
    return


def raum_aufgang_vorfall2_von_nord():
    print(f"{Fore.WHITE}[Du verlässt den Ort des Vorfalls und folgst der vor dir liegenden Abzweigung nach Süden.]{Fore.GREEN}\n")
    WARTEN2()
    print("Der Weg endet an einer Felswand. \n")
    WARTEN2()
    print("Nach Osten geht es von hier aus nicht weiter, aber direkt vor dir führt ein schmaler Gang nach Süden.\n")
    WARTEN2()
    print("Natürlich könntest du auch immer noch zurück nach Westen gehen.\n")
    WARTEN2()
    befehl = input("Wo willst du hin? (Optionen: Westen, Süden) \n > ").lower()
    if "süd" in befehl:
        return befehl
    elif "west" in befehl:
        return befehl
    else:
        HOPPLA()
